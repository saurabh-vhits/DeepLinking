import SvgIndex from '@svgIndex';
import React, {FC} from 'react';
import {
  ImageBackground,
  ImageProps,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {styles} from './myProgramHorizontalCard.style';

interface MyProgramHorizontalCardProps {
  item: ItemProps;
  index: number;
  onPress?: () => void;
}
interface ItemProps {
  id?: number;
  tag?: string;
  rating?: number;
  subscriber?: string;
  title?: string;
  duration?: string;
  level?: string;
  name?: string;
  backgroundImage?: ImageProps;
  price?: string;
}
const MyProgramHorizontalCard: FC<MyProgramHorizontalCardProps> = ({
  item,
  onPress,
}) => {
  return (
    <TouchableOpacity
      key={item?.id}
      activeOpacity={0.8}
      style={styles.Container}
      onPress={onPress}>
      <ImageBackground
        source={item?.backgroundImage}
        resizeMode="cover"
        style={styles.bgImage}>
        <View style={styles.tagView}>
          <Text style={styles.tagText} allowFontScaling={false}>
            {item?.tag}
          </Text>
        </View>
        <View style={styles.detailsView}>
          <View style={styles.subcriberView}>
            <View style={styles.ratingCard}>
              <Text style={styles.ratingText} allowFontScaling={false}>
                {item?.rating}
              </Text>
              <View style={styles.ratingIcon}>
                <SvgIndex.starPurpal />
              </View>
            </View>
            <View style={styles.subscriberCard}>
              <Text style={styles.ratingText} allowFontScaling={false}>
                {item?.subscriber}
              </Text>
              <View style={styles.ratingIcon}>
                <SvgIndex.userPurpal />
              </View>
            </View>
          </View>
          <View style={styles.blurCard}>
            <View style={styles.infoView}>
              <Text style={styles.titleText} allowFontScaling={false}>
                {item?.title}
              </Text>
              <Text style={styles.durationText} allowFontScaling={false}>
                {item?.duration}, {item?.level}
              </Text>
              <Text style={styles.nameText} allowFontScaling={false}>
                {item?.name}
              </Text>
            </View>
            <TouchableOpacity
              activeOpacity={0.8}
              style={styles.addToCardButton}>
              <View style={styles.cartIcon}>
                <SvgIndex.dollor />
              </View>
              <Text style={styles.priceText} allowFontScaling={false}>
                {item?.price}$
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ImageBackground>
    </TouchableOpacity>
  );
};

export default MyProgramHorizontalCard;
