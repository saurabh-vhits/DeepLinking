import imageIndex from '@imageIndex';
import SvgIndex from '@svgIndex';
import React, {FC, memo} from 'react';
import {ImageBackground, Text, TouchableOpacity, View} from 'react-native';
import {styles} from './bodyweightExercise.style';

interface BodyweightExerciseProps {
  item: ExercisesProps;
  index?: number;
  drag?: () => void;
  isActive?: boolean;
  exerciseType?: string;
  isLastIndex?: boolean;
  onPressCheckBox?: () => void;
  onPressDelete?: () => void;
  onPressSets?: () => void;
  onPressMatric?: () => void;
  onPressRestTime?: () => void;
  onPressCoolDown?: () => void;
  onPressUploadVideo?: () => void;
}

export interface ExercisesProps {
  defaultParametersReps: string;
  defaultParametersSets: string;
  defaultParametersSetsType: string;
  defaultParametersMetric: string;
  defaultParametersMetricType: string;
  defaultParametersResttime: string;
  defaultParametersResttimeType: string;
  defaultParametersCooldown: string;
  defaultParametersCooldownType: string;
  equipment: string;
  exercisesId: string;
  isSelected: boolean;
  mainMuscle: string;
  ownerType: string;
  secondaryMuscle: string;
  tags: string;
  title: string;
  trainerInstructions: string;
  videoId: string;
}

const BodyweightExercise: FC<BodyweightExerciseProps> = ({
  item,
  index,
  drag,
  isActive,
  exerciseType,
  isLastIndex,
  onPressCheckBox,
  onPressDelete,
  onPressSets,
  onPressMatric,
  onPressRestTime,
  onPressCoolDown,
  onPressUploadVideo,
}) => {
  // console.log('item:', item?.defaultParametersSetsType);
  const isSuperset = exerciseType === 'Superset' && isLastIndex;
  const isCircuit = exerciseType === 'Circuit' && isLastIndex;
  return (
    <View style={styles.container}>
      {/* Header card */}
      <View style={styles.headerCard}>
        <View style={styles.checkBoxRow}>
          <TouchableOpacity
            activeOpacity={0.6}
            style={styles.checkBoxIcon}
            onPress={onPressCheckBox}>
            {item?.isSelected ? (
              <SvgIndex.checkboxFilled height={11} width={11} />
            ) : (
              <SvgIndex.checkboxEmpty height={11} width={11} />
            )}
          </TouchableOpacity>
          <Text allowFontScaling={false} style={styles.backSquatText}>
            Back Squat
          </Text>
        </View>
        <View style={styles.deleteBoxRow}>
          <TouchableOpacity
            activeOpacity={0.6}
            style={styles.deleteIcon}
            onPress={onPressDelete}>
            <SvgIndex.deleteSolid />
          </TouchableOpacity>
          <TouchableOpacity
            activeOpacity={0.6}
            style={styles.hambirgIcon}
            onLongPress={drag}>
            <SvgIndex.hamburg />
          </TouchableOpacity>
        </View>
      </View>

      {/* Thumbnail */}
      <View style={styles.thumbnailView}>
        <View style={styles.thumbnail}>
          <ImageBackground
            source={imageIndex.frame}
            resizeMode="cover"
            style={styles.thumbnailImage}>
            <TouchableOpacity
              activeOpacity={0.6}
              style={styles.uploadButton}
              onPress={onPressUploadVideo}>
              <SvgIndex.publish />
              <Text allowFontScaling={false} style={styles.uploadVideoText}>
                Upload video
              </Text>
            </TouchableOpacity>
          </ImageBackground>
        </View>
      </View>

      {/* Instructions */}
      <View style={styles.instructionView}>
        <View style={styles.instructionHeading}>
          <Text allowFontScaling={false} style={styles.instructionTitle}>
            Coach Instructions
          </Text>
          {item?.trainerInstructions && (
            <Text allowFontScaling={false} style={styles.count}>
              {item?.trainerInstructions?.length}/10000
            </Text>
          )}
        </View>
        <Text allowFontScaling={false} style={styles.instructionValue}>
          {item?.trainerInstructions}
        </Text>
      </View>

      {/* Sets, Metric, Resttime, Cooldown */}
      <View style={styles.metricView}>
        <View style={styles.setsRow}>
          <Text allowFontScaling={false} style={styles.setHeadingText}>
            Sets
          </Text>
          <TouchableOpacity
            activeOpacity={0.6}
            style={styles.setsCard}
            onPress={onPressSets}>
            <View style={styles.setNumberView}>
              <Text allowFontScaling={false} style={styles.setNumberText}>
                {item?.defaultParametersSets}
              </Text>
            </View>
            <View style={styles.verticalLine} />
            <View style={styles.setStringView}>
              <Text allowFontScaling={false} style={styles.setStringText}>
                {item?.defaultParametersSetsType}
              </Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.setsRow}>
          <Text allowFontScaling={false} style={styles.setHeadingText}>
            Metric
          </Text>
          <TouchableOpacity
            activeOpacity={0.6}
            style={styles.setsCard}
            onPress={onPressMatric}>
            <View style={styles.setNumberView}>
              <Text allowFontScaling={false} style={styles.setNumberText}>
                {item?.defaultParametersMetric}
              </Text>
            </View>
            <View style={styles.verticalLine} />
            <View style={styles.setStringView}>
              <Text allowFontScaling={false} style={styles.setStringText}>
                {item?.defaultParametersMetricType === 'Repetitions'
                  ? 'Reps'
                  : item?.defaultParametersMetricType?.slice(0, 3)}
              </Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.setsRow}>
          <Text allowFontScaling={false} style={styles.setHeadingText}>
            Rest Time
          </Text>
          <TouchableOpacity
            activeOpacity={0.6}
            style={styles.setsCard}
            onPress={onPressRestTime}>
            <View style={styles.setNumberView}>
              <Text allowFontScaling={false} style={styles.setNumberText}>
                {item?.defaultParametersResttime}
              </Text>
            </View>
            <View style={styles.verticalLine} />
            <View style={styles.setStringView}>
              <Text allowFontScaling={false} style={styles.setStringText}>
                {item?.defaultParametersResttimeType?.slice(0, 3)}
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.setsRow}>
          <Text allowFontScaling={false} style={styles.setHeadingText}>
            Cool down
          </Text>
          <TouchableOpacity
            activeOpacity={0.6}
            style={styles.setsCard}
            onPress={onPressCoolDown}>
            <View style={styles.setNumberView}>
              <Text allowFontScaling={false} style={styles.setNumberText}>
                {item?.defaultParametersCooldown}
              </Text>
            </View>
            <View style={styles.verticalLine} />
            <View style={styles.setStringView}>
              <Text allowFontScaling={false} style={styles.setStringText}>
                {item?.defaultParametersCooldownType?.slice(0, 3)}
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default memo(BodyweightExercise);
