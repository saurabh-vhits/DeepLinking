import React, {FC, memo} from 'react';
import {Text, TextStyle, TouchableOpacity, View, ViewStyle} from 'react-native';
import {styles} from './uploadCard.style';

interface UploadCardProps {
  lable?: string;
  lableStyle?: TextStyle;
  optionalLable?: string;
  icon?: React.JSX.ElementType
  uploadText?: string;
  ratioText?: string;
  containerStyle?: ViewStyle;
  uploadContainerStyle?: ViewStyle;
  onPress?: () => void;
  ratioTextStyle?: TextStyle;
}
const UploadCard: FC<UploadCardProps> = ({
  containerStyle,
  lable,
  optionalLable,
  onPress,
  uploadContainerStyle,
  uploadText,
  ratioText,
  ratioTextStyle,
  lableStyle,
  ...props
}) => {
  return (
    <View style={[styles.container, containerStyle]}>
      {lable && (
        <Text allowFontScaling={false} style={[styles.lable, lableStyle]}>
          {lable}{' '}
          {optionalLable && (
            <Text allowFontScaling={false} style={styles.optionalLable}>
              {optionalLable}
            </Text>
          )}
        </Text>
      )}
      <TouchableOpacity
        activeOpacity={0.7}
        onPress={onPress}
        style={[styles.uploadContainer, uploadContainerStyle]}>
        {props?.icon && <props.icon />}
        {uploadText && (
          <Text allowFontScaling={false} style={styles.uploadText}>
            {uploadText}
          </Text>
        )}
        {ratioText && (
          <Text
            allowFontScaling={false}
            style={[styles.ratioText, ratioTextStyle]}>
            {ratioText}
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );
};

export default memo(UploadCard);
