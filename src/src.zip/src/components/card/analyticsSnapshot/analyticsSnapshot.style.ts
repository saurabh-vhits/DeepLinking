import color from '@theme/color';
import font from '@theme/font';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  fContainer: {
    height: 92,
    borderRadius: 5,
    paddingVertical: 5,
    paddingHorizontal: 8,
    backgroundColor: color.primary,
    width: '100%',
    alignItems: 'center',
    marginBottom: 12,
  },
  fContentView: {
    height: 63,
    alignItems: 'center',
  },
  fTitle: {
    fontFamily: font.openSansRegular,
    fontWeight: '700',
    fontSize: 14,
    lineHeight: 19,
    color: color.secondaryBG,
  },
  averageView:{
     height: 16,
     alignSelf:'center' 
  },
  fType: {
    fontFamily: font.openSansRegular,
    fontWeight: '400',
    fontSize: 10,
    lineHeight: 18,
    color: color.primaryText,
  },
  fAmount: {
    marginTop: 7,
    fontFamily: font.openSansRegular,
    fontWeight: '700',
    fontSize: 30,
    lineHeight: 40,
    color: color.secondaryBG,
  },
  fProgressView: {
    marginTop: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  fProgressValue: {
    fontFamily: font.openSansRegular,
    fontWeight: '600',
    fontSize: 10,
    lineHeight: 13,
    color: color.secondaryBG,
  },
  fProgressText: {
    fontFamily: font.openSansRegular,
    fontWeight: '400',
    fontSize: 10,
    lineHeight: 13,
    color: color.secondaryBG,
  },
  hContainer: {
    paddingVertical: 5,
    paddingHorizontal: 8,
    backgroundColor: color.primaryBG,
    alignItems: 'flex-start',
    borderRadius: 5,
    width: '48.2%',
  },
  hContentView: {
    // height: 63,
    alignItems: 'flex-start',
  },
  hTitle: {
    fontFamily: font.openSansSemiBold,
    fontSize: 14,
    lineHeight: 19,
    color: color.primaryText,
  },
  hAmount: {
    marginTop: 10,
    fontFamily: font.openSansSemiBold,
    fontSize: 25,
    lineHeight: 34,
    color: color.primaryText,
  },
  hProgressView: {
    marginTop: 5,
    flexDirection: 'row',
  },
  hProgressValue: {
    flex: 1,
    fontFamily: font.openSansRegular,
    fontWeight: '600',
    fontSize: 10,
    lineHeight: 13.62,
    color: color.primary,
  },
  hProgressText: {
    fontFamily: font.openSansRegular,
    fontWeight: '400',
    fontSize: 10,
    lineHeight: 13.62,
    color: color.primaryText,
  },
  iconView: {
    marginRight: 2,
    // height: 13,
    // width: 13,
    // justifyContent: 'center',
    // alignItems: 'center',
  },
  isSelected: {
    borderWidth: 1,
    borderColor: color.primary,
  },
});
