import SvgIndex from '@svgIndex';
import React, {FC, memo, useRef, useState} from 'react';
import {FlatList, Text, TouchableOpacity, View, ViewStyle} from 'react-native';
import {styles} from './analyticsCarousel.style';
interface DataItem {
  id: number;
  title: string;
  amount: string;
  progress: string;
}
interface CarouselItem {
  data: DataItem[];
}
interface AnalyticsCarouselProps {
  data: CarouselItem[];
  containerStyle?: ViewStyle;
}
const AnalyticsCarousel: FC<AnalyticsCarouselProps> = ({
  data,
  containerStyle,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const [selected, setSelected] = useState<number | null>(null);

  const handleDotPress = (index: number) => {
    flatListRef.current?.scrollToIndex({index});
    setCurrentIndex(index);
  };
  //** Handle highlight item */
  const handleSelect = (id: number) => {
    setSelected(id === selected ? null : id);
  };

  const renderList = ({item}: {item: DataItem}) => {
    const isSelected = selected === item.id;
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => handleSelect(item?.id)}
        key={item?.id}
        style={[styles.card, isSelected && styles.isSelected]}>
        {item?.amount && (
          <View style={styles.cardTitleView}>
            <Text
              allowFontScaling={false}
              style={styles.cardTitle}
              numberOfLines={1}>
              {item?.title}
            </Text>
            <Text allowFontScaling={false} style={styles.amount}>
              {item?.amount}
            </Text>
          </View>
        )}
        {item?.progress && (
          <View style={styles.progressView}>
            <View style={styles.iconView}>
              <SvgIndex.trendingUp />
            </View>
            <Text allowFontScaling={false} style={styles.progrssPercent}>
              {item?.progress}%{' '}
              <Text allowFontScaling={false} style={styles.progrssText}>
                Increase of active users
              </Text>
            </Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };
  const renderItem = ({item}: {item: CarouselItem}) => {
    return (
      <FlatList
        key={item?.data[0]?.id}
        contentContainerStyle={styles.contentContainerStyle}
        data={item?.data}
        keyExtractor={list => list?.id?.toString()}
        numColumns={2}
        renderItem={renderList}
        bounces={false}
      />
    );
  };
  return (
    <View style={[styles.container, containerStyle]}>
      <FlatList
        ref={flatListRef}
        data={data}
        renderItem={renderItem}
        showsHorizontalScrollIndicator={false}
        keyExtractor={(_, index) => index?.toString()}
        horizontal
        pagingEnabled
        bounces={false}
        contentContainerStyle={styles.contentContainerStyle}
      />
      <View style={styles.dotsContainer}>
        {data?.map((_, index) => (
          <TouchableOpacity
            key={index}
            style={styles.dotView}
            onPress={() => handleDotPress(index)}>
            <View
              style={[styles.dot, index === currentIndex && styles.activeDot]}
            />
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};
export default memo(AnalyticsCarousel);
