import color from '@theme/color';
import font from '@theme/font';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 11,
    backgroundColor: color.secondaryBG,
    borderRadius: 10,
  },
  contentContainerStyle: {
    flexGrow: 1,
    
  },
  dotsContainer: {
    flexDirection: 'row',
    alignSelf: 'center',
    marginTop: 11,
    marginBottom: 7,
  },
  dotView: {
    width: 8,
    height: 8,
    borderRadius: 5,
    backgroundColor: color.primary,
    marginHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dot: {
    height: 6,
    width: 6,
    borderRadius: 5,
    backgroundColor: color.secondaryBG,
  },
  activeDot: {
    backgroundColor: color.primary,
  },
  slide: {
    width: '100%',
    height: '100%',
  },
  card: {
    backgroundColor: color.primaryBG,
    // width: '50%',
    // height: 92,
    marginRight: 13,
    marginBottom: 13,
    borderRadius: 5,
    paddingHorizontal: 8,
    paddingVertical: 5,
  },
  cardTitleView: {
    height: 63,
    width: 147,
  },
  cardTitle: {
    fontFamily: font.openSansSemiBold,
    fontSize: 14,
    lineHeight: 19,
    color: color.secondaryText,
  },
  amount: {
    marginTop: 10,
    fontFamily: font.openSansSemiBold,
    fontSize: 25,
    lineHeight: 34,
    color: color.primaryText,
  },
  progressView: {
    marginTop: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconView: {
    height: 13,
    width: 13,
    marginRight: 2,
  },
  progrssPercent: {
    fontFamily: font.openSansRegular,
    fontWeight: '600',
    fontSize: 10,
    lineHeight: 13.62,
    color: color.primary,
  },
  progrssText: {
    fontFamily: font.openSansRegular,
    fontWeight: '400',
    fontSize: 10,
    lineHeight: 13.62,
    color: color.primaryText,
  },
  isSelected: {
    borderWidth: 1,
    borderColor: color.primary,
  },
});
