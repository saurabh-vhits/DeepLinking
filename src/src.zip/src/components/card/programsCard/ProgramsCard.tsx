import imageIndex from '@imageIndex';
import SvgIndex from '@svgIndex';
import React, { FC, memo } from 'react';
import { Image, Text, TouchableOpacity, View } from 'react-native';
import { styles } from './programsCard.style';

interface ProgramsCardProps {
  item: ItemProps;
  index: number;
  isSelected?: boolean;
  rightIcon?: React.JSX.ElementType;
  showCheckBox?: boolean;
  onPress?: () => void;
  onPressRightIcon?: () => void;
  onPressCheckBox?: () => void;
}
interface ItemProps {
  exercisesId?: string;
  videoId?: string;
  title?: string;
  ownerType?: string;
  mainMuscle?: string;
  secondaryMuscle?: string;
  tags?: string;
  equipment?: string;
  defaultParametersSets?: string;
  defaultParametersReps?: string;
  trainerInstructions?: string;
  checked?: boolean;
}

const ProgramsCard: FC<ProgramsCardProps> = ({
  item,
  index,
  onPress,
  onPressRightIcon,
  onPressCheckBox,
  showCheckBox,
  isSelected,
  ...props
}) => {
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      style={[styles.container, isSelected && styles.isCardSelected]}>
      <View style={styles.imageView}>
        <Image
          source={imageIndex.programs}
          style={styles.image}
          resizeMode="contain"
        />
      </View>
      <View style={styles.detailsView}>
        <Text allowFontScaling={false} numberOfLines={2} style={styles.titleText}>
        {item?.title}
        </Text>
        <Text allowFontScaling={false} numberOfLines={2} style={styles.desText}>
          {`Full body, ${item?.mainMuscle} & ${item?.secondaryMuscle}, ${item?.tags}, ${item?.equipment} | Resistance`}
        </Text>
      </View>
      {props?.rightIcon && (
        <TouchableOpacity
          onPress={onPressRightIcon}
          activeOpacity={0.8}
          style={styles.deleteIcon}>
          <props.rightIcon />
        </TouchableOpacity>
      )}
      {showCheckBox && (
        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.deleteIcon}
          onPress={onPressCheckBox}>
          {item?.checked ? (
            <SvgIndex.checkboxFilled />
          ) : (
            <SvgIndex.checkboxEmpty />
          )}
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
};

export default memo(ProgramsCard);
ProgramsCard.defaultProps = {
  showCheckBox: false,
};
