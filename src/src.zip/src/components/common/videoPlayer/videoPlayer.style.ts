import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  video: {
    width: '100%',
    borderRadius: 5,
  },
});
