export type MyProgramStackParams = {
  MyPrograms: undefined;
  MyWorkoutLibrary: undefined;
};

