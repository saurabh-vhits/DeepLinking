export const filtersList = [
  {id: 1, title: 'Device', defaultValue: 'iOS, Android'},
  {id: 2, title: 'Dates', defaultValue: '14 / 08 / 2023   -   18 / 08 / 2023'},
  {id: 3, title: 'Country', defaultValue: 'israel, Spain'},
];
