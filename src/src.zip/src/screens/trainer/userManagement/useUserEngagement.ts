import { useAuthNavigation } from '@hooks/useAppNavigation';
import { useCallback, useState } from 'react';
import {
  chartInformationList,
  graphFilters,
  userManagementList,
  userOverviewList,
} from './userEngagement.const';
import { UserEngagementProps } from './UserEngagement';

const useUserEngagement = () => {
  const navigation = useAuthNavigation();
  const [userEngagementState, setUserEngagementState] =
    useState<UserEngagementProps>({
      userOverview: userOverviewList,
      chartInformation: chartInformationList,
      graphFilterOptions: graphFilters,
      userData: userManagementList,
      selectedValue: 'Last Week',
    });

  //** Update use management state */
  const updateUserEngagementState = useCallback(
    (key: string, value: string | boolean) => {
      setUserEngagementState(prevState => ({...prevState, [key]: value}));
    },
    [userEngagementState],
  );

  //** Navigate to filter screen */
  const navigateToFilterScreen = useCallback(() => {
    navigation.navigate('AnalyticsFilters');
  }, []);

  return {
    userEngagementState,
    updateUserEngagementState,
    navigateToFilterScreen,
  };
};
export default useUserEngagement;
