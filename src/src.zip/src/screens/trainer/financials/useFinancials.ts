const useFinancials = () => {
  return {};
};

export default useFinancials;


