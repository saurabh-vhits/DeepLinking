import {axiosInstance} from '@api/api';
import constant from '@config/constant';
import * as param from '@config/params';
import {useAuthNavigation, useAuthRoute} from '@hooks/useAppNavigation';
import {useAppSelector} from '@hooks/useRedux';
import {useIsFocused} from '@react-navigation/native';
import {Toast} from '@utility/functions/toast';
import {Log} from '@utility/log';
import {checkString} from '@utility/validation/stringValidation';
import validationMessage from '@utility/validation/validationMessage';
import {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import ImageCropPicker from 'react-native-image-crop-picker';
import RBSheet from 'react-native-raw-bottom-sheet';
import {ExercisesProps} from 'src/components/card/bodyweightExercise/BodyweightExercise';
import {DaysProps} from '../programName/ProgramName';
import {
  BodyWeightOnlyErrorProps,
  BodyWeightOnlyProps,
  supersetAndCircuitProps,
} from './BodyWeightOnly';

const useBodyWeightOnly = () => {
  const navigation = useAuthNavigation();
  const {token} = useAppSelector(state => state.UserData);
  const {params} = useAuthRoute('BodyWeightOnly');
  const isFocused = useIsFocused();
  const refRBSheetTableSets = useRef<RBSheet>(null);

  const [bodyWeightOnlyState, setBodyWeightOnlyState] =
    useState<BodyWeightOnlyProps>({
      programId: '',
      weeksDaysList: [],
      initialVisibleWeeks: 3,
      showAllWeeks: false,
      currentIndex: 0,
      weeklyId: '',
      sessionName: '',
      workoutIntroVideo: '',
      workoutSummaryVideo: '',
      isLoading: false,
      selectedExercises: [],
      supersetAndCircuit: [],
      selectType: undefined,
      selectedWeekAndDay: [],
      setButtons: ['Superset', 'Circuit'],
      dataCount: 0,

      // sets
      selectedType: 'Sets',
      selectedIndex: 0,
      selectedSupersetIndex: 0,
    });
  const [bodyWeightOnlyError, setBodyWeightOnlyError] =
    useState<BodyWeightOnlyErrorProps>({
      sessionNameError: undefined,
      exerciseError: undefined,
    });

  //** Update bodyweight only state values */
  const updateBodyWeightOnlyState = useCallback(<T>(key: string, value: T) => {
    setBodyWeightOnlyState(prevState => ({...prevState, [key]: value}));
  }, []);
  useEffect(() => {
    if (
      isFocused &&
      params?.numberOfWeeks &&
      JSON.stringify(params?.numberOfWeeks) !==
        JSON.stringify(bodyWeightOnlyState?.weeksDaysList) &&
      bodyWeightOnlyState?.dataCount == 0
    ) {
      const selectedDay = params?.numberOfWeeks?.filter(week =>
        week?.days?.some((day: DaysProps) => day?.isSelected),
      );
      const selectedWeekAndDay = selectedDay?.map(week => ({
        weekName: week?.weekName,
        dayName: week?.days?.find((day: DaysProps) => day?.isSelected)?.dayName,
      }));
      updateBodyWeightOnlyState('selectedWeekAndDay', selectedWeekAndDay);
      updateBodyWeightOnlyState('weeksDaysList', params?.numberOfWeeks);
      updateBodyWeightOnlyState('dataCount', 1);
    }
  }, [
    isFocused,
    params?.numberOfWeeks,
    bodyWeightOnlyState?.weeksDaysList,
    updateBodyWeightOnlyState,
  ]);

  useEffect(() => {
    if (
      isFocused &&
      params?.programId &&
      params?.weeklyId &&
      bodyWeightOnlyState?.programId !== params?.programId &&
      bodyWeightOnlyState?.weeklyId !== params?.weeklyId
    ) {
      updateBodyWeightOnlyState('programId', params?.programId);
      updateBodyWeightOnlyState('weeklyId', params?.weeklyId);
    }
  }, [
    isFocused,
    params?.programId,
    params?.weeklyId,
    updateBodyWeightOnlyState,
  ]);

  useEffect(() => {
    if (
      isFocused &&
      params?.selectedExercises &&
      params?.exerciseFlag == 'NewExercise'
    ) {
      const combinedExercises = [
        ...bodyWeightOnlyState.selectedExercises,
        ...params?.selectedExercises
          ?.filter(item => {
            const existingExercise = bodyWeightOnlyState.selectedExercises.find(
              ex => ex?.exercisesId === item?.exercisesId,
            );
            return !existingExercise;
          })
          .map(item => ({
            ...item,
            isSelected: false,
            defaultParametersSets: '3',
            defaultParametersSetsType: 'Sets',
            defaultParametersMetric: '120',
            defaultParametersMetricType: 'Sec',
            defaultParametersResttime: '90',
            defaultParametersResttimeType: 'Sec',
            defaultParametersCooldown: '90',
            defaultParametersCooldownType: 'Sec',
          })),
      ];
      updateBodyWeightOnlyState('selectedExercises', combinedExercises);
    }
  }, [
    isFocused,
    params?.exerciseFlag,
    params?.selectedExercises,
    updateBodyWeightOnlyState,
  ]);

  useEffect(() => {
    if (
      isFocused &&
      params?.selectedExercises &&
      params?.exerciseFlag === 'FromSet' &&
      bodyWeightOnlyState?.supersetAndCircuit !== params?.selectedExercises
    ) {
      const updatedExercises = [...bodyWeightOnlyState.supersetAndCircuit];
      if (params?.setIndex !== undefined) {
        if (updatedExercises[params?.setIndex]?.exercisesList) {
          const existingExercisesIds = updatedExercises[
            params?.setIndex
          ]?.exercisesList?.map(exercise => exercise?.exercisesId);
          const newExercises = params?.selectedExercises
            ?.filter(
              exercise =>
                !existingExercisesIds?.includes(exercise?.exercisesId),
            )
            .map(exercise => ({
              ...exercise,
              isSelected: true,
              defaultParametersSets: '3',
              defaultParametersSetsType: 'Sets',
              defaultParametersMetric: '120',
              defaultParametersMetricType: 'Sec',
              defaultParametersResttime: '90',
              defaultParametersResttimeType: 'Sec',
              defaultParametersCooldown: '90',
              defaultParametersCooldownType: 'Sec',
            }));
          updatedExercises[params?.setIndex].exercisesList = [
            ...updatedExercises[params?.setIndex].exercisesList,
            ...newExercises,
          ];
        }
      }
      updateBodyWeightOnlyState('supersetAndCircuit', updatedExercises);
    }
  }, [
    isFocused,
    params?.exerciseFlag,
    params?.setIndex,
    params?.selectedExercises,
    updateBodyWeightOnlyState,
  ]);

  //** Get the week index which one day is selected  */
  const getSelectedWeekIndex = useMemo(() => {
    return bodyWeightOnlyState?.weeksDaysList?.findIndex(week =>
      week?.days?.some(day => day?.isSelected),
    );
  }, [bodyWeightOnlyState?.weeksDaysList]);

  useEffect(() => {
    updateBodyWeightOnlyState('currentIndex', getSelectedWeekIndex);
  }, [getSelectedWeekIndex]);

  //** Handle add new session button active inactive */
  const isAddNewSession = useMemo(
    () => !bodyWeightOnlyState.sessionName,
    [bodyWeightOnlyState],
  );

  const isRemoveButton = useMemo(() => {
    const updatedSuperset = bodyWeightOnlyState?.supersetAndCircuit;
    if (updatedSuperset && updatedSuperset.length > 0) {
      return updatedSuperset.some(current => {
        return current?.exercisesList?.every(exercise => !exercise?.isSelected);
      });
    }
    return false;
  }, [bodyWeightOnlyState?.supersetAndCircuit]);

  //** Chnage week of data index wise */
  const onChangeWeek = useCallback(
    (type: string) => {
      switch (type) {
        case 'NextIndex':
          if (
            bodyWeightOnlyState?.currentIndex <
            bodyWeightOnlyState?.weeksDaysList?.length - 1
          ) {
            updateBodyWeightOnlyState(
              'currentIndex',
              bodyWeightOnlyState?.currentIndex + 1,
            );
          }
          break;
        case 'PrevIndex':
          if (bodyWeightOnlyState?.currentIndex > 0) {
            updateBodyWeightOnlyState(
              'currentIndex',
              bodyWeightOnlyState?.currentIndex - 1,
            );
          }
          break;
        default:
          break;
      }
    },
    [bodyWeightOnlyState],
  );

  //** Select week of day */
  const onSelectWeekOfDays = useCallback(
    (dayId: number, weekIndex: number, weekName: string) => {
      updateBodyWeightOnlyState('currentIndex', weekIndex);
      const updatedWeeks = bodyWeightOnlyState?.weeksDaysList?.map(
        (week, index) => {
          if (index === weekIndex) {
            return {
              ...week,
              days: week?.days?.map(day =>
                day?.id === dayId
                  ? {...day, isSelected: true}
                  : {...day, isSelected: false},
              ),
            };
          } else {
            return {
              ...week,
              days: week?.days?.map(day => ({...day, isSelected: false})),
            };
          }
        },
      );
      updateBodyWeightOnlyState('weeksDaysList', updatedWeeks);
      apiWeeklyDay(weekName, dayId);
      if (updatedWeeks) {
        const selectedDays = updatedWeeks?.filter(week =>
          week?.days?.some(day => day?.isSelected),
        );
        const result = selectedDays?.map(week => ({
          weekName: week?.weekName,
          dayName: week?.days?.find(day => day?.isSelected)?.dayName,
        }));
        updateBodyWeightOnlyState('selectedWeekAndDay', result);
      }
    },
    [bodyWeightOnlyState],
  );

  //** Start api integration for posting day of the week */
  const apiWeeklyDay = async (week: string, day: number) => {
    try {
      let tempWeek = week.split(' ')[1];
      const formData = {
        [param.default.day]: day,
        [param.default.week]: parseInt(tempWeek),
        [param.default.programId]: bodyWeightOnlyState?.programId,
      };
      const {data} = await axiosInstance.post(constant.weeklyDay, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (data) {
        updateBodyWeightOnlyState('weeklyId', data?.weeklyId);
        if (data?.weeklyId) {
          validateCreateSession(2);
        }
      }
    } catch (error) {
      Log('Weekly day failed', error);
    }
  };
  //** End api integration for posting day of the week */

  //** Start Upload workout intro & summary videos */
  const uploadWorkoutVideo = useCallback(
    async (videoType: 'Intro' | 'Summary') => {
      const video = await ImageCropPicker.openPicker({
        mediaType: 'video',
        compressVideoPreset: 'HighestQuality',
      });
      const key =
        videoType === 'Intro' ? 'workoutIntroVideo' : 'workoutSummaryVideo';
      updateBodyWeightOnlyState(key, video?.path);
    },
    [bodyWeightOnlyState],
  );
  //** End Upload workout intro & summary videos */

  //** Navigate to exercise screen to select exercise */
  const navigateToNewExercise = useCallback(
    (exerciseFlag: 'NewExercise' | 'FromSet', index?: number) => {
      switch (exerciseFlag) {
        case 'NewExercise':
          navigation.navigate('Exercise', {
            flag: 'bodyWeightOnly',
            exerciseFlag,
            selectedExercises: bodyWeightOnlyState?.selectedExercises,
          });
          break;
        case 'FromSet':
          if (index !== undefined) {
            navigation.navigate('Exercise', {
              flag: 'bodyWeightOnly',
              exerciseFlag,
              setIndex: index,
              selectedExercises:
                bodyWeightOnlyState?.supersetAndCircuit[index]?.exercisesList,
            });
          }
          break;
        default:
          break;
      }
    },
    [bodyWeightOnlyState, navigation],
  );
  //** Start Create session api integration */
  const onCreateSession = async (from: number) => {
    if (from === 0) {
      updateBodyWeightOnlyState('isLoading', true);
    }
    try {
      const exerciseWithSet = bodyWeightOnlyState?.supersetAndCircuit?.map(
        set => {
          let exerciseList = set?.exercisesList?.map(ex => {
            return {
              exercisesId: ex?.exercisesId,
              sets: ex?.defaultParametersSets,
              reps: ex?.defaultParametersReps,
              restTime: 1,
              coolDown: 1,
            };
          });
          return {
            type: set?.type,
            exercise: exerciseList,
          };
        },
      );
      const exercises =
        bodyWeightOnlyState?.selectType !== undefined
          ? exerciseWithSet
          : bodyWeightOnlyState?.selectedExercises;
      let formData = new FormData();
      if (bodyWeightOnlyState?.workoutIntroVideo) {
        formData.append(param.default.videoIntroOne, {
          name: 'video.mp4',
          uri: bodyWeightOnlyState?.workoutIntroVideo,
          type: 'video/mp4',
        });
      }
      if (bodyWeightOnlyState?.workoutSummaryVideo) {
        formData.append(param.default.videoIntroTwo, {
          name: 'video.mp4',
          uri: bodyWeightOnlyState?.workoutSummaryVideo,
          type: 'video/mp4',
        });
      }
      formData.append(
        param.default.sessionData,
        JSON.stringify({
          exercises: exercises,
          programId: bodyWeightOnlyState?.programId,
          weeklyId: bodyWeightOnlyState?.weeklyId,
          sessionName: bodyWeightOnlyState?.sessionName,
        }),
      );
      Log('formData::', JSON.stringify(formData));
      const {data} = await axiosInstance.post(
        constant.sessionCreate,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );
      Toast('Session Created Successfully !!');
      updateBodyWeightOnlyState('isLoading', false);
      updateBodyWeightOnlyState('sessionName', '');
      updateBodyWeightOnlyState('workoutIntroVideo', '');
      updateBodyWeightOnlyState('workoutSummaryVideo', '');
      updateBodyWeightOnlyState('selectedExercises', []);
      updateBodyWeightOnlyState('supersetAndCircuit', []);
      if (from == 0) {
        // navigation.navigate('WorkoutPlan', {
        //   programId: bodyWeightOnlyState?.programInfo?.programId,
        // });
      } else if (from == 1) {
        navigation.navigate('ProgramName', {
          numberOfWeeks: bodyWeightOnlyState?.weeksDaysList,
        });
        updateBodyWeightOnlyState('dataCount', 0);
      }
    } catch (error: any) {
      Toast(error?.data?.message);
      Log('create session failed', error);
      updateBodyWeightOnlyState('isLoading', false);
    }
  };
  //** End Create session api integration */

  //** Start validate to Create session */
  const validateCreateSession = useCallback(
    (from: number = 0) => {
      let tempError = {};
      if (!checkString(bodyWeightOnlyState?.sessionName)) {
        tempError = {
          sessionNameError: validationMessage.emptySessionName,
        };
      } else if (
        !(
          bodyWeightOnlyState?.selectType == 'Superset' ||
          bodyWeightOnlyState?.selectType == 'Circuit'
        )
      ) {
        if (bodyWeightOnlyState?.selectedExercises?.length <= 1) {
          tempError = {
            exerciseError: validationMessage.emptyExercise,
          };
        }
      } else {
        tempError = {};
        onCreateSession(from);
      }
      setBodyWeightOnlyError(tempError);
    },
    [
      bodyWeightOnlyState,
      bodyWeightOnlyError,
      validationMessage,
      onCreateSession,
    ],
  );
  //** End validate to Create session */

  //** Back icon press hit the create session api */
  const onPressBack = useCallback(() => {
    updateBodyWeightOnlyState('dataCount', 0);
    validateCreateSession(1);
  }, [bodyWeightOnlyState, validateCreateSession, navigation]);

  //** Upload exercise video */
  const onUploadExerciseVideo = useCallback(async () => {
    const exerciseVideo = await ImageCropPicker.openPicker({
      mediaType: 'video',
      compressVideoPreset: 'HighestQuality',
    });
  }, [bodyWeightOnlyState]);

  //** Create Superset & Circuit */
  const onCreateSupersetAndCircuit = useCallback(
    (type: string) => {
      let temp = [...bodyWeightOnlyState?.supersetAndCircuit];
      let tempExerciseList = [...bodyWeightOnlyState?.selectedExercises];
      let tempExercise = tempExerciseList
        ?.filter(item => item?.isSelected)
        .map(item => {
          return {
            restTime: 1,
            coolDown: 2,
            ...item,
          };
        });
      temp.push({
        exercisesList: tempExercise,
        type: type,
        isSetEnable: true,
        isSet: true,
      });
      tempExerciseList = tempExerciseList?.filter(
        i => !tempExercise?.some(j => j?.exercisesId === i?.exercisesId),
      );
      updateBodyWeightOnlyState('supersetAndCircuit', temp);
      updateBodyWeightOnlyState('selectedExercises', tempExerciseList);
      updateBodyWeightOnlyState('selectType', type);
    },
    [bodyWeightOnlyState, updateBodyWeightOnlyState],
  );

  //** Remove Superset & Circuit */
  // const onRemoveSupersetAndCircuit = useCallback((i:Array<number>) => {
  //   // if (bodyWeightOnlyState?.supersetAndCircuit?.length <= 1) {
  //   //   updateBodyWeightOnlyState('selectType', undefined);
  //   // }
  //   // const indices = bodyWeightOnlyState?.supersetAndCircuit?.reduce(
  //   //   (acc: Array<number>, item, index) => {
  //   //     if (item?.exercisesList?.some(exercise => exercise?.isSelected)) {
  //   //       acc.push(index);
  //   //     }
  //   //     return acc;
  //   //   },
  //   //   [],
  //   // );
  //   // let temp = [...bodyWeightOnlyState?.supersetAndCircuit];
  //   // const index = indices[0];
  //   // temp?.splice(index, 1);
  //   // updateBodyWeightOnlyState('supersetAndCircuit', temp);
  //   if (bodyWeightOnlyState?.supersetAndCircuit) {
  //     let temp = [...bodyWeightOnlyState.supersetAndCircuit];
  //     for (let index of i.sort((a, b) => b - a)) {
  //       temp.splice(index, 1);
  //     }
  //     updateBodyWeightOnlyState('supersetAndCircuit', temp);
  //   }
  // }, [bodyWeightOnlyState, updateBodyWeightOnlyState]);
  const onRemoveSupersetAndCircuit = useCallback(
    (items: Array<number>) => {
      if (bodyWeightOnlyState?.supersetAndCircuit) {
        updateBodyWeightOnlyState('supersetAndCircuit', [
          ...bodyWeightOnlyState.supersetAndCircuit.filter(
            (_, index) => !items.includes(index),
          ),
        ]);
      }
    },
    [bodyWeightOnlyState, updateBodyWeightOnlyState],
  );

  // Start Select exercise for Creating Supersets & Circuit And Remove Superset & Circuit
  const onSelectExercise = useCallback(
    (
      type: 'Exercise' | 'Set',
      exercisesId?: string,
      exerciseIndex?: number,
      setIndex?: number,
    ) => {
      switch (type) {
        case 'Exercise':
          const updatedExercise = bodyWeightOnlyState?.selectedExercises?.map(
            exercise => {
              if (exercise?.exercisesId === exercisesId) {
                const updatedExercise = {
                  ...exercise,
                  isSelected: !exercise.isSelected,
                };
                return updatedExercise;
              }
              return exercise;
            },
          );
          updateBodyWeightOnlyState('selectedExercises', updatedExercise);
          break;
        case 'Set':
          if (
            setIndex !== undefined &&
            bodyWeightOnlyState?.supersetAndCircuit[setIndex]?.exercisesList
              ?.length <= 1
          ) {
            updateBodyWeightOnlyState('selectType', undefined);
          }
          let temp = bodyWeightOnlyState?.supersetAndCircuit?.map(
            (circuit, circuitKey) => {
              if (circuitKey === setIndex) {
                return {
                  ...circuit,
                  exercisesList: circuit?.exercisesList?.map(
                    (exercise, index) => {
                      if (index === exerciseIndex) {
                        return {...exercise, isSelected: !exercise.isSelected};
                      }
                      return exercise;
                    },
                  ),
                };
              }
              return circuit;
            },
          );
          updateBodyWeightOnlyState('supersetAndCircuit', temp);
          break;
        default:
          break;
      }
    },
    [bodyWeightOnlyState, updateBodyWeightOnlyState],
  );
  // End Select exercise for Creating Supersets & Circuit And Remove Superset & Circuit

  // Start Delete exercise from selected exercise And Superset & Circuit
  const onDeleteExercise = useCallback(
    (
      type: 'Exercise' | 'Set',
      exercisesId?: string,
      exerciseIndex?: number,
      setIndex?: number,
    ) => {
      switch (type) {
        case 'Exercise':
          const updatedExercise =
            bodyWeightOnlyState?.selectedExercises?.filter(
              exercise => exercise.exercisesId !== exercisesId,
            );
          updateBodyWeightOnlyState('selectedExercises', updatedExercise);
          break;
        case 'Set':
          if (setIndex !== undefined && exerciseIndex !== undefined) {
            if (
              bodyWeightOnlyState?.supersetAndCircuit[setIndex]?.exercisesList
                ?.length <= 1
            ) {
              updateBodyWeightOnlyState('selectType', undefined);
            }
            if (
              bodyWeightOnlyState?.supersetAndCircuit[setIndex]?.exercisesList
                ?.length == 1
            ) {
              let temp = [...bodyWeightOnlyState?.supersetAndCircuit];
              temp.splice(setIndex, 1);
              updateBodyWeightOnlyState('supersetAndCircuit', temp);
            } else {
              let temp = [
                ...bodyWeightOnlyState?.supersetAndCircuit[setIndex]
                  .exercisesList,
              ];
              temp.splice(exerciseIndex, 1);

              if (bodyWeightOnlyState?.supersetAndCircuit[setIndex]) {
                bodyWeightOnlyState.supersetAndCircuit[setIndex].exercisesList =
                  temp;
              }
              updateBodyWeightOnlyState('supersetAndCircuit', [
                ...bodyWeightOnlyState?.supersetAndCircuit,
              ]);
            }
          }
          break;
        default:
          break;
      }
    },
    [bodyWeightOnlyState, updateBodyWeightOnlyState],
  );
  // End Delete exercise from selected exercise And Superset & Circuit

  //** update data on drag  */
  const onDragEnd = (data: ExercisesProps[], index: number) => {
    const updatedSupersetAndCircuit = [
      ...bodyWeightOnlyState.supersetAndCircuit,
    ];
    if (index >= 0 && index < updatedSupersetAndCircuit.length) {
      updatedSupersetAndCircuit[index] = {
        ...updatedSupersetAndCircuit[index],
        exercisesList: data,
      };
      updateBodyWeightOnlyState(
        'supersetAndCircuit',
        updatedSupersetAndCircuit,
      );
    }
  };

  //** Open bottom sheet to selected Sets, Metric, Rest time, Cool down */
  const openBottomSheet = (
    type: string,
    index?: number,
    supersetIndex?: number,
  ) => {
    refRBSheetTableSets?.current?.open();
    updateBodyWeightOnlyState('selectedType', type);
    updateBodyWeightOnlyState('selectedIndex', index);
    updateBodyWeightOnlyState('selectedSupersetIndex', supersetIndex);
  };

  //** set value of Sets, Metric, Rest time, Cool down */
  const updateExerciseParameters = (
    updatedExercises: ExercisesProps[],
    selectedIndex: number | undefined,
    parameterKey: string,
    data: string,
  ) => {
    if (selectedIndex !== undefined && updatedExercises[selectedIndex]) {
      const updatedExercise = {...updatedExercises[selectedIndex]};
      updatedExercise[parameterKey] = data;
      updatedExercises[selectedIndex] = updatedExercise;
      updateBodyWeightOnlyState('selectedExercises', updatedExercises);
    }
  };

  const updateExerciseParametersa = (
    updatedExercises: supersetAndCircuitProps[],
    selectedIndex: number | undefined,
    supersetIndex: number | undefined,
    parameterKey: string,
    data: string,
  ) => {
    if (
      selectedIndex !== undefined &&
      supersetIndex !== undefined &&
      updatedExercises[supersetIndex]?.exercisesList[selectedIndex]
    ) {
      const updatedExercise = {
        ...updatedExercises[supersetIndex]?.exercisesList[selectedIndex],
      };
      updatedExercise[parameterKey] = data;
      updatedExercises[supersetIndex].exercisesList[selectedIndex] =
        updatedExercise;
      console.log('updatedExercise', updatedExercise);
      updateBodyWeightOnlyState('supersetAndCircuit', [...updatedExercises]);
    }
  };

  const onSelectSetsMetric = (
    data: string,
    type: 'Sets' | 'Metric' | 'Resttime' | 'Cooldown',
    from: 'Value' | 'Type',
    superset: number,
  ) => {
    const selectedIndex = bodyWeightOnlyState.selectedIndex;
    const supersetIndex = bodyWeightOnlyState.selectedSupersetIndex;
    const updatedSupersetExercises = [
      ...bodyWeightOnlyState.supersetAndCircuit,
    ];
    const updatedExercises = [...bodyWeightOnlyState.selectedExercises];
    const parameterKey = `${
      from === 'Value' ? 'defaultParameters' : 'defaultParameters'
    }${type}${from === 'Value' ? '' : 'Type'}`;

    if (
      superset === 1 &&
      selectedIndex !== undefined &&
      supersetIndex !== undefined
    ) {
      updateExerciseParametersa(
        updatedSupersetExercises,
        selectedIndex,
        supersetIndex,
        parameterKey,
        data,
      );
    } else if (superset === 0 && selectedIndex !== undefined) {
      updateExerciseParameters(
        updatedExercises,
        selectedIndex,
        parameterKey,
        data,
      );
    }
  };

  return {
    bodyWeightOnlyState,
    bodyWeightOnlyError,
    updateBodyWeightOnlyState,
    isAddNewSession,
    onChangeWeek,
    onSelectWeekOfDays,
    uploadWorkoutVideo,
    navigateToNewExercise,
    validateCreateSession,
    onPressBack,
    onCreateSupersetAndCircuit,
    onUploadExerciseVideo,
    onRemoveSupersetAndCircuit,
    onSelectExercise,
    onDeleteExercise,
    isRemoveButton,
    onDragEnd,
    refRBSheetTableSets,
    openBottomSheet,
    onSelectSetsMetric,
  };
};

export default useBodyWeightOnly;
