import {BodyweightExercise, WeeksDays} from '@card';
import {
  Button,
  CustomStatusbar,
  ErrorText,
  Header,
  InputContainer,
} from '@components';
import SvgIndex from '@svgIndex';
import color from '@theme/color';
import React, {FC} from 'react';
import {
  FlatList,
  ScrollView,
  Text,
  TouchableHighlight,
  TouchableOpacity,
  View,
} from 'react-native';
import DraggableFlatList from 'react-native-draggable-flatlist';
import 'react-native-gesture-handler';
import Video from 'react-native-video';
import {ExercisesProps} from 'src/components/card/bodyweightExercise/BodyweightExercise';
import {WeeksDaysListProps} from '../programName/ProgramName';
import styles from './bodyWeightOnly.style';
import useBodyWeightOnly from './useBodyWeightOnly';

export interface BodyWeightOnlyProps {
  programId: string;
  weeksDaysList: WeeksDaysListProps[];
  initialVisibleWeeks: number;
  showAllWeeks: boolean;
  currentIndex: number;
  weeklyId: string;
  sessionName: string;
  workoutIntroVideo: string;
  workoutSummaryVideo: string;
  isLoading: boolean;
  selectedExercises: ExercisesProps[];
  supersetAndCircuit: supersetAndCircuitProps[];
  selectType?: string;
  selectedWeekAndDay: SelectedWeekAndDayProps[];
  setButtons: string[];
  dataCount: number;
}
interface ProgramInfoProps {
  numberOfWeeks?: number;
  programId?: string;
  programsName?: string;
  weeklyId?: string;
}
export interface BodyWeightOnlyErrorProps {
  sessionNameError?: string;
  exerciseError?: string;
}
interface SelectedWeekAndDayProps {
  weekName: string;
  dayName: string;
}
export interface supersetAndCircuitProps {
  exercisesList: ExercisesProps[];
  type: string;
  isSetEnable: boolean;
  isSet: boolean;
}

const BodyWeightOnly: FC = () => {
  const {
    bodyWeightOnlyState,
    bodyWeightOnlyError,
    updateBodyWeightOnlyState,
    isAddNewSession,
    onChangeWeek,
    onSelectWeekOfDays,
    uploadWorkoutVideo,
    navigateToNewExercise,
    validateCreateSession,
    onPressBack,
    onCreateSupersetAndCircuit,
    onUploadExerciseVideo,
    onRemoveSupersetAndCircuit,
    onSelectExercise,
    onDeleteExercise,
    isRemoveButton,
    onDragEnd,
  } = useBodyWeightOnly();
  return (
    <View style={styles.container}>
      <CustomStatusbar
        barStyle="dark-content"
        backgroundColor={color.transparent}
      />
      <Header
        showBackIcon
        lable={'BodyWeight Only'}
        containerStyle={styles.headerContainer}
        lableStyle={styles.headerText}
        onPressBackIcon={onPressBack}
      />
      <ScrollView
        style={styles.mainContainer}
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled={true}>
        <View style={styles.weekListView}>
          <View style={styles.arrowView}>
            <TouchableHighlight
              underlayColor={color.lightgray}
              disabled={bodyWeightOnlyState.currentIndex == 0}
              activeOpacity={0.6}
              onPress={() => onChangeWeek('PrevIndex')}
              style={styles.arrowBtn}>
              <SvgIndex.arrowUp />
            </TouchableHighlight>
            
            <TouchableHighlight
              underlayColor={color.lightgray}
              disabled={
                !(bodyWeightOnlyState?.weeksDaysList?.length > 3) ||
                bodyWeightOnlyState?.currentIndex ===
                  bodyWeightOnlyState?.weeksDaysList?.length - 1
              }
              activeOpacity={0.6}
              onPress={() => onChangeWeek('NextIndex')}
              style={styles.arrowBtn}>
              <SvgIndex.downArrowLine />
            </TouchableHighlight>
          </View>
          <FlatList
            data={[
              bodyWeightOnlyState?.weeksDaysList?.[
                bodyWeightOnlyState?.currentIndex
                  ? bodyWeightOnlyState?.currentIndex
                  : 0
              ],
            ]}
            keyExtractor={(_, index) => {
              return `${index}`;
            }}
            contentContainerStyle={styles.contentContainerWeekStyle}
            renderItem={({item, index}) => (
              <WeeksDays
                key={item?.id}
                item={item}
                index={index}
                onPressDay={res =>
                  onSelectWeekOfDays(
                    res,
                    bodyWeightOnlyState?.currentIndex,
                    item?.weekName,
                  )
                }
              />
            )}
            showsVerticalScrollIndicator={false}
          />
        </View>
        {/* session details */}
        <View style={styles.sessionDetail}>
          {bodyWeightOnlyState?.selectedWeekAndDay?.length > 0 && (
            <Text
              allowFontScaling={false}
              numberOfLines={1}
              style={styles.sessionText}>
              {`${bodyWeightOnlyState?.selectedWeekAndDay[0]?.weekName} Day ${bodyWeightOnlyState?.selectedWeekAndDay[0]?.dayName}`}
            </Text>
          )}
          <InputContainer
            placeholder="Enter Session Name"
            placeholderTextColor={color.primaryText}
            label="Session Name"
            labelStyle={styles.labelText}
            lableRowStyle={styles.lableRowStyle}
            inputContainerStyle={styles.inputContainer}
            value={bodyWeightOnlyState?.sessionName}
            onChangeText={text =>
              updateBodyWeightOnlyState('sessionName', text)
            }
            error={bodyWeightOnlyError?.sessionNameError}
            errorLabelStyle={styles.errorLabelStyle}
          />
          <View style={styles.introVideoView}>
            <Text
              allowFontScaling={false}
              numberOfLines={1}
              style={styles.labelText}>
              Add workout intro{'  '}
              <Text allowFontScaling={false} style={styles.optionalText}>
                (optional)
              </Text>
            </Text>
            <View style={styles.introUpload}>
              {!bodyWeightOnlyState?.workoutIntroVideo ? (
                <TouchableOpacity
                  style={styles.uploadCard}
                  onPress={() => uploadWorkoutVideo('Intro')}>
                  <SvgIndex.upload />
                  <Text allowFontScaling={false} style={styles.uploadDes}>
                    Upload your trailer video{'\n'} add a 9:16 ratio video
                  </Text>
                </TouchableOpacity>
              ) : (
                <Video
                  source={{uri: bodyWeightOnlyState?.workoutIntroVideo}}
                  resizeMode="cover"
                  style={styles.introVideo}
                  muted={true}
                  paused={true}
                  controls={true}
                />
              )}
            </View>
          </View>
          <View style={styles.exerciseContainer}>
            {/* Buttons (superset & circuit) */}
            <View style={styles.buttonView}>
              {!isRemoveButton && bodyWeightOnlyState?.selectType ? (
                <TouchableHighlight
                  style={styles.removeBtn}
                  underlayColor={color.lightgray}
                  disabled={!isRemoveButton}
                  onPress={onRemoveSupersetAndCircuit}>
                  <View style={styles.btnRow}>
                    <Text
                      allowFontScaling={false}
                      style={styles.removeBtnTitle}>
                      {bodyWeightOnlyState?.selectType == 'Superset'
                        ? 'Remove Superset'
                        : 'Remove Circuit'}
                    </Text>
                    <SvgIndex.minus />
                  </View>
                </TouchableHighlight>
              ) : (
                <>
                  {bodyWeightOnlyState?.setButtons?.map(button => (
                    <TouchableHighlight
                      style={styles.supersetBtn}
                      disabled={
                        bodyWeightOnlyState?.selectedExercises?.filter(
                          ex => ex?.isSelected,
                        )?.length < 2
                      }
                      underlayColor={color.lightgray}
                      onPress={() =>
                        onCreateSupersetAndCircuit(button?.toString())
                      }>
                      <View style={styles.btnRow}>
                        <Text allowFontScaling={false} style={styles.btnTitle}>
                          {button}
                        </Text>
                        <SvgIndex.plusPurple />
                      </View>
                    </TouchableHighlight>
                  ))}
                </>
              )}
            </View>

            {/* exercise card */}
            {bodyWeightOnlyState?.supersetAndCircuit?.filter(
              item => item?.isSet,
            ).length != 0 && (
              <>
                {bodyWeightOnlyState?.supersetAndCircuit?.map((sup, idx) => (
                  <View style={styles.supersetList}>
                    <View style={styles.header}>
                      <Text allowFontScaling={false} style={styles.headingText}>
                        {sup?.type ? sup?.type : 'Title'}
                      </Text>
                      <TouchableHighlight style={styles.headingHamburg}>
                        <SvgIndex.hamburgPurpal />
                      </TouchableHighlight>
                    </View>
                    <DraggableFlatList
                      contentContainerStyle={styles.dragContentContainer}
                      data={sup?.exercisesList}
                      keyExtractor={(_, index) => {
                        return `${index}`;
                      }}
                      renderItem={({item, drag, isActive, getIndex}) => {
                        const currentIndex = getIndex() as number;
                        const isLastIndex =
                          currentIndex === sup?.exercisesList?.length - 1;
                        return (
                          <BodyweightExercise
                            key={item?.exercisesId}
                            item={item}
                            drag={drag}
                            isActive={isActive}
                            index={currentIndex}
                            onPressCheckBox={() =>
                              onSelectExercise('Set', '', currentIndex, idx)
                            }
                            onPressDelete={() =>
                              onDeleteExercise('Set', '', currentIndex, idx)
                            }
                            onPressUploadVideo={onUploadExerciseVideo}
                            exerciseType={
                              bodyWeightOnlyState?.supersetAndCircuit[idx]?.type
                            }
                            isLastIndex={isLastIndex}
                          />
                        );
                      }}
                      onDragEnd={({data}) => onDragEnd(data, idx)}
                      showsVerticalScrollIndicator={false}
                    />
                    <TouchableHighlight
                      style={styles.exerciseCard}
                      underlayColor={color.lightgray}
                      onPress={() => navigateToNewExercise('FromSet', idx)}>
                      <Text
                        allowFontScaling={false}
                        style={styles.exerciseCardText}>
                        {'+  '}New Exercise
                      </Text>
                    </TouchableHighlight>
                  </View>
                ))}
              </>
            )}
            {bodyWeightOnlyState?.selectedExercises?.length !== 0 && (
              <View style={styles.exerciseList}>
                <DraggableFlatList
                  contentContainerStyle={styles.dragContentContainer}
                  data={bodyWeightOnlyState?.selectedExercises}
                  keyExtractor={(_, index) => {
                    return `${index}`;
                  }}
                  renderItem={({item, drag, isActive, getIndex}) => {
                    const currentIndex = getIndex();
                    return (
                      <BodyweightExercise
                        key={item?.exercisesId}
                        item={item}
                        drag={drag}
                        isActive={isActive}
                        index={currentIndex}
                        onPressCheckBox={() =>
                          onSelectExercise('Exercise', item?.exercisesId)
                        }
                        onPressDelete={() =>
                          onDeleteExercise('Exercise', item?.exercisesId)
                        }
                        onPressUploadVideo={onUploadExerciseVideo}
                      />
                    );
                  }}
                  onDragEnd={({data}) =>
                    updateBodyWeightOnlyState('selectedExercises', data)
                  }
                  showsVerticalScrollIndicator={false}
                />
              </View>
            )}
            <TouchableHighlight
              style={styles.exerciseCard}
              underlayColor={color.lightgray}
              onPress={() => navigateToNewExercise('NewExercise')}>
              <Text allowFontScaling={false} style={styles.exerciseCardText}>
                {'+  '}New Exercise
              </Text>
            </TouchableHighlight>
            <View style={styles.error}>
              <ErrorText error={bodyWeightOnlyError?.exerciseError} />
            </View>
          </View>
          <View style={styles.introVideoView}>
            <Text
              allowFontScaling={false}
              numberOfLines={1}
              style={styles.labelText}>
              Add workout summary{'  '}
              <Text allowFontScaling={false} style={styles.optionalText}>
                (optional)
              </Text>
            </Text>
            <View style={styles.introUpload}>
              {!bodyWeightOnlyState?.workoutSummaryVideo ? (
                <TouchableOpacity
                  style={styles.uploadCard}
                  onPress={() => uploadWorkoutVideo('Summary')}>
                  <SvgIndex.upload />
                  <Text allowFontScaling={false} style={styles.uploadDes}>
                    Upload your trailer video{'\n'} add a 9:16 ratio video
                  </Text>
                </TouchableOpacity>
              ) : (
                <Video
                  source={{uri: bodyWeightOnlyState?.workoutSummaryVideo}}
                  resizeMode="cover"
                  style={styles.introVideo}
                  muted={true}
                  paused={true}
                  controls={true}
                />
              )}
            </View>
          </View>
        </View>
        <View style={styles.btnView}>
          <Button
            disabled={isAddNewSession}
            inActive={isAddNewSession}
            isLoading={bodyWeightOnlyState?.isLoading}
            onPress={() => validateCreateSession(0)}
            label="Add new Session"
          />
        </View>
      </ScrollView>
    </View>
  );
};

export default BodyWeightOnly;
