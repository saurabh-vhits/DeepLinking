export const currencyLists = [
  {
    id: 1,
    title: 'USD - US Doller',
  },
  {
    id: 2,
    title: 'US Doller',
  }
];
