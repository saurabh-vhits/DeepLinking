import imageIndex from '@imageIndex';

export const programsList = [
  {
    id: 1,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: true,
  },
  {
    id: 2,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: false,
  },
  {
    id: 3,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: true,
  },
  {
    id: 4,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: false,
  },
  {
    id: 5,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: true,
  },
  {
    id: 6,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: false,
  },
  {
    id: 7,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: true,
  },
  {
    id: 8,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: true,
  },
  {
    id: 9,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
    checked: true,
  },
];
