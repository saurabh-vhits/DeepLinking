import {useAuthNavigation} from '@hooks/useAppNavigation';
import {useCallback, useState} from 'react';
import {OverviewProps} from './Overview';
import {
  analyticsOverviewList,
  chartInformationList,
  graphFilters,
} from './overview.const';

const useOverview = () => {
  const navigation = useAuthNavigation();
  const [overviewInfo, setOverviewInfo] = useState<OverviewProps>({
    overviewList: analyticsOverviewList,
    chartInformation: chartInformationList,
    graphFilterOptions: graphFilters,
    selectedValue: 'Last Week',
  });

  //** Update overview state */
  const updateOverviewState = useCallback(
    (key: string, value: string) => {
      setOverviewInfo(prevState => ({...prevState, [key]: value}));
    },
    [overviewInfo],
  );

  //** Handle filter onpress */
  const navigateToFilterScreen = useCallback(() => {
    navigation.navigate('AnalyticsFilters');
  }, []);

  return {
    overviewInfo,
    updateOverviewState,
    navigateToFilterScreen,
  };
};

export default useOverview;
