import color from '@theme/color';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: color.primaryBG,
  },
  dropdownContainer: {
    height: 40,
    borderRadius: 2,
    padding: 10,
    backgroundColor: color.secondaryBG,
    paddingHorizontal: 10,
    marginTop: 20,
    marginBottom: 20,
  },
  placeholderStyle: {
    fontSize: 15,
    color: color.primaryText,
    lineHeight: 22,
  },
  graphContainerStyle: {
    marginTop: 12,
    marginBottom: 50,
  },
});
