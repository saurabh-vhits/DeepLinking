import {useAuthNavigation} from '@hooks/useAppNavigation';
import {useCallback, useState} from 'react';

const useChangePassword = () => {
  const navigation = useAuthNavigation();
  const [passwordChange, setPasswordChange] = useState({
    oldPassword: '12345678',
    newPassword: '',
    confirmPassword: '12345678',
    confirmationModal: false,
  });

  const [passwordChangeError, setPasswordChangeError] = useState({
    oldPasswordError: undefined,
    newPasswordError: undefined,
    confirmPasswordError: undefined,
  });

  //** Handle state change */
  const updatePasswordChange = useCallback(
    (key: string, value: string | boolean) => {
      setPasswordChange(prevState => ({...prevState, [key]: value}));
    },
    [passwordChange],
  );

  //** Navigate to change email screen */
  const onPressSaveChanges = useCallback(() => {
    // navigation.navigate('ChangeEmail');
  }, []);

  //** Email change confirmations modal handler */
  const handleModal = useCallback(() => {
    updatePasswordChange(
      'confirmationModal',
      !passwordChange?.confirmationModal,
    );
  }, [passwordChange]);

  return {
    passwordChange,
    updatePasswordChange,
    onPressSaveChanges,
    handleModal,
  };
};

export default useChangePassword;
