export const filterDataExercise = [
  {
    id: 1,
    title: 'Library',
  },
  {
    id: 2,
    title: 'Type',
  },
  {
    id: 3,
    title: 'Main Muscle',
  },
];

export const filterDataLibrary = [
  {
    id: 1,
    title: 'Type',
  },
  {
    id: 2,
    title: 'Main Muscle',
  },
];
