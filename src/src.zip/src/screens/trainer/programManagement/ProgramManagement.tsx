import { AnalyticsCarousel } from '@card';
import { Dropdown, FinancialGraph } from '@components';
import SvgIndex from '@svgIndex';
import React, { FC } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { styles } from './programManagement.style';
import useProgramManagement from './useProgramManagement';

export interface ProgramManagementProps {
  programOverviewList: ProgramOverviewItemProps[];
  chartInformation: ChartInformationProps[];
  graphFilterOptions: graphFilterOptionsProps[];
  selectedValue: string;
}
interface ProgramOverviewItemProps {
  id: number;
  data: ProgramOverviewDataItem[];
}
interface ProgramOverviewDataItem {
  id: number;
  title: string;
  amount: string;
  description: string;
  progress: string;
}
interface ChartInformationProps {
  value: number;
  date?: string;
}
interface graphFilterOptionsProps {
  id: number;
  title: string;
}

const ProgramManagement: FC = () => {
  const {
    programManagement,
    updateProgramManagementState,
    navigateToFilterScreen,
  } = useProgramManagement();
  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
        bounces={false}>
        <Dropdown
          containerStyle={styles.dropdownContainer}
          placeholder="All Programs"
          placeholderStyle={styles.placeholderStyle}
          showRightIcon
          onPressRight={navigateToFilterScreen}
          filterRowContainer={styles.rowView}
        />
        <View style={styles.priceRowViewStyle}>
          <View style={styles.rowDollorIconView}>
            <SvgIndex.dollorBorderIcon />
            <View style={styles.textManageTextView}>
              <Text allowFontScaling={false} style={styles.priceTextStyle}>
                Price
              </Text>
              <Text allowFontScaling={false} style={styles.priceUKTextStyle}>
                $12k
              </Text>
            </View>
          </View>
          <View style={styles.activeCardStyleView}>
            <View style={styles.activePoinStyle} />
            <Text allowFontScaling={false} style={styles.activeTextPoint}>
              Active
            </Text>
          </View>
        </View>
        <AnalyticsCarousel data={programManagement?.programOverviewList} />
        <FinancialGraph
          title="Total Subscribers"
          chartData={programManagement?.chartInformation}
          data={programManagement?.graphFilterOptions}
          showDropdown
          placeholder="Last Week"
          value={programManagement?.selectedValue}
          setValue={res => updateProgramManagementState('selectedValue', res)}
          containerStyle={styles.graphContainerStyle}
        />
      </ScrollView>
    </View>
  );
};

export default ProgramManagement;
