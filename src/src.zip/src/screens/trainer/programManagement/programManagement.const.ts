const chartInformationList = [
  {
    value: 400,
    date: '16/02/23',
  },
  {
    value: 330,
  },
  {
    value: 320,
  },
  {
    value: 310,
  },
  {
    value: 230,
    date: '16/02/23',
  },
  {
    value: 200,
  },
  {
    value: 270,
  },
  {
    value: 240,
  },
  {
    value: 130,
    date: '16/02/23',
  },
  {
    value: 120,
  },
  {
    value: 100,
  },
  {
    value: 210,
  },
  {
    value: 270,
    date: '16/02/23',
  },
  {
    value: 240,
  },
  {
    value: 120,
  },
  {
    value: 100,
  },
  {
    value: 210,
    date: '16/02/23',
  },
  {
    value: 20,
  },
  {
    value: 100,
  },
];

const graphFilters = [
  {
    id: 1,
    title: 'Last Week',
  },
  {
    id: 2,
    title: 'Last 24h',
  },
  {
    id: 3,
    title: 'Last Month',
  },
  {
    id: 4,
    title: 'Last Year',
  },
  {
    id: 5,
    title: 'Max',
  },
];

const programManagementOverview = [
  {
    id: 1,
    data: [
      {
        id: 1,
        title: 'Earnings',
        amount: '$3,000',
        description: 'Increase of active users',
        progress: '8',
      },
      {
        id: 2,
        title: 'Total Subscribers',
        amount: '35,000',
        description: 'Increase of active users',
        progress: '5',
      },
      {
        id: 3,
        title: 'New Subscribers',
        amount: '35,000',
        description: 'Increase of active users',
        progress: '10',
      },
      {
        id: 4,
        title: 'Viewership',
        amount: '35,000',
        description: 'Increase of active users',
        progress: '2',
      },
    ],
  },
  {
    id: 2,
    data: [
      {
        id: 1,
        title: 'Active Subscribers ',
        amount: '35,000',
        description: 'Increase of active users',
        progress: '5',
      },
      {
        id: 2,
        title: 'Total Programs',
        amount: '3,527',
        description: 'Increase of active users',
        progress: '8',
      },
      {
        id: 3,
        title: 'Referrals Conversion',
        amount: '35,000',
        description: 'Increase of active users',
        progress: '10',
      },
      {
        id: 4,
        title: 'Rate Viewership',
        amount: '60%',
        description: 'Increase of active users',
        progress: '2',
      },
    ],
  },
  {
    id: 3,
    data: [
      {
        id: 1,
        title: 'User engagement',
        amount: '35,000',
        description: 'Increase of active users',
        progress: '5',
      },
    ],
  },
];

export {chartInformationList, graphFilters, programManagementOverview};
