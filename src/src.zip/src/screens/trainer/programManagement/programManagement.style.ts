import color from '@theme/color';
import font from '@theme/font';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: color.primaryBG,
  },
  dropdownContainer: {
    height: 40,
    borderRadius: 2,
    padding: 10,
    backgroundColor: color.secondaryBG,
    paddingHorizontal: 10,
  },
  placeholderStyle: {
    fontFamily: font.openSansRegular,
    fontWeight: '400',
    fontSize: 15,
    lineHeight: 20.43,
    color: color.primaryText,
  },
  rowView: {
    marginTop: 20.91,
    marginBottom: 13,
  },
  priceRowViewStyle: {
    flexDirection: 'row',
    marginBottom: 14,
  },
  textManageTextView: {
    marginLeft: 6,
  },
  priceTextStyle: {
    fontSize: 10,
    fontFamily: font.openSansSemiBold,
    color: color.secondaryText,
  },
  priceUKTextStyle: {
    fontSize: 14,
    fontFamily: font.openSansSemiBold,
    color: color.primaryText,
  },
  activeCardStyleView: {
    width: 70,
    borderRadius: 50,
    backgroundColor: color.forestGreen,
    paddingHorizontal: 8,
    paddingVertical: 4,
    alignItems: 'center',
    flexDirection: 'row',
  },
  activePoinStyle: {
    height: 7,
    width: 7,
    borderRadius: 40,
    backgroundColor: color.viridianGreen,
    marginRight: 7,
  },
  activeTextPoint: {
    fontSize: 12,
    fontFamily: font.openSansRegular,
    color: color.viridianGreen,
  },
  graphContainerStyle: {
    marginTop: 12,
    marginBottom: 50,
  },
  rowDollorIconView: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
});
