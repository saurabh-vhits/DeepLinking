import { useAuthNavigation } from '@hooks/useAppNavigation';
import { useCallback, useState } from 'react';
import { ProgramManagementProps } from './ProgramManagement';
import {
  chartInformationList,
  graphFilters,
  programManagementOverview,
} from './programManagement.const';

const useProgramManagement = () => {
  const navigation = useAuthNavigation();
  const [programManagement, setProgramManagement] =
    useState<ProgramManagementProps>({
      programOverviewList: programManagementOverview,
      chartInformation: chartInformationList,
      graphFilterOptions: graphFilters,
      selectedValue: 'Last Week',
    });

  //** Handle state change values */
  const updateProgramManagementState = useCallback(
    (key: string, value: string | boolean) => {
      setProgramManagement(prevState => ({...prevState, [key]: value}));
    },
    [programManagement],
  );

  //** Handle filter onpress */
  const navigateToFilterScreen = useCallback(() => {
    navigation.navigate('AnalyticsFilters');
  }, []);

  return {
    programManagement,
    updateProgramManagementState,
    navigateToFilterScreen,
  };
};

export default useProgramManagement;
