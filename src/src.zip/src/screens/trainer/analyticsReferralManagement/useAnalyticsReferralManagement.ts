import { useAuthNavigation } from '@hooks/useAppNavigation';
import svgIndex from '@svgIndex';
import { useCallback, useRef, useState } from 'react';
import { AnalyticsReferralManagementProps } from './AnalyticsReferralManagement';
import {
  bottomSheetList,
  referralManagementList,
} from './analyticsReferralManagement.const';

const useAnalyticsReferralManagement = () => {
  const navigation = useAuthNavigation();
  const refRBSheet = useRef<any>([]);
  const [referralInfo, setReferralInfo] =
    useState<AnalyticsReferralManagementProps>({
      referralList: referralManagementList,
      filterReferralList: referralManagementList,
      bottomSheetList: bottomSheetList,
      searchItem: '',
      activateReferral: false,
    });

  //** Update refferal state */
  const updateReferralState = useCallback(
    (key: string, value: string | Array<object> | boolean) => {
      setReferralInfo(prevState => ({...prevState, [key]: value}));
    },
    [referralInfo],
  );

  //** Open the operation bottom sheet */
  const openMenuSheet = useCallback(
    (index: number) => {
      refRBSheet.current[index]?.open();
    },
    [refRBSheet],
  );

  //** Navigate to filter screen */
  const navigateToFilterScreen = useCallback(() => {
    navigation.navigate('AnalyticsFilters');
  }, []);

  //** Handle referral item search */
  const onSearchReferral = useCallback(
    (text: string) => {
      updateReferralState('searchItem', text);
      const filteredList = referralInfo?.filterReferralList?.filter(item => {
        return (
          item?.referralCode?.toLowerCase()?.includes(text?.toLowerCase()) ||
          item?.referredBy?.toLowerCase()?.includes(text?.toLowerCase()) ||
          item?.discount?.toLowerCase()?.includes(text?.toLowerCase()) ||
          item?.noOfSubs?.toLowerCase()?.includes(text?.toLowerCase()) ||
          item?.conversionRate?.toLowerCase()?.includes(text?.toLowerCase()) ||
          item?.revenueGenerated?.toLowerCase()?.includes(text?.toLowerCase())
        );
      });
      updateReferralState('referralList', filteredList);
    },
    [referralInfo, referralManagementList],
  );

  // handle bottom sheet operations
  const handleSheetOperations = useCallback(
    (id: number) => {
      if (id === 1 || id !== 2) return;
      const updatedBottomSheetList = (referralInfo?.bottomSheetList || []).map(
        item =>
          item?.id === id
            ? {
                ...item,
                title: item.title === 'Activate' ? 'Deactivate' : 'Activate',
                icon:
                  item.title === 'Activate'
                    ? svgIndex.deactivate
                    : svgIndex.activate,
              }
            : item,
      );
      updateReferralState('bottomSheetList', updatedBottomSheetList);
      updateReferralState('activateReferral', !referralInfo?.activateReferral);
    },
    [referralInfo, updateReferralState],
  );

  return {
    referralInfo,
    refRBSheet,
    openMenuSheet,
    navigateToFilterScreen,
    onSearchReferral,
    handleSheetOperations,
  };
};

export default useAnalyticsReferralManagement;
