import imageIndex from '@imageIndex';

export const programsList = [
  {
    id: 1,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 2,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 3,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 4,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 5,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
];
