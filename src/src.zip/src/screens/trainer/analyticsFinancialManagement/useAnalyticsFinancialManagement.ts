import {useAuthNavigation} from '@hooks/useAppNavigation';
import {useCallback, useState} from 'react';
import {graphFilters} from '../overview/overview.const';
import {AnalyticsFinancialManagementProps} from './AnalyticsFinancialManagement';
import {
  chartInformationList,
  payoutList,
} from './analyticsFinancialManagement.const';

const useAnalyticsFinancialManagement = () => {
  const navigation = useAuthNavigation();
  const [analyticsFinancialManagement, setAnalyticsFinancialManagement] =
    useState<AnalyticsFinancialManagementProps>({
      payoutList: payoutList,
      chartInformation: chartInformationList,
      graphFilterOptions: graphFilters,
      selectedValue: 'Last Week',
    });

  //** Handle state change values */
  const handleChangeValue = useCallback(
    (key: string, value: string) => {
      setAnalyticsFinancialManagement(prevState => ({
        ...prevState,
        [key]: value,
      }));
    },
    [analyticsFinancialManagement],
  );

  //** Handle filter onpress */
  const navigateToFilterScreen = useCallback(() => {
    navigation.navigate('AnalyticsFilters');
  }, []);

  return {
    analyticsFinancialManagement,
    handleChangeValue,
    navigateToFilterScreen,
  };
};
export default useAnalyticsFinancialManagement;
