const useDuplicateSession = () => {
  return {};
};
export default useDuplicateSession;
