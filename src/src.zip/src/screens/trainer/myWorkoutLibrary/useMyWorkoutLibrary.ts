import { axiosInstance } from '@api/api';
import constant from '@config/constant';
import { useAuthNavigation, useAuthRoute } from '@hooks/useAppNavigation';
import { useAppSelector } from '@hooks/useRedux';
import { useIsFocused } from '@react-navigation/native';
import { RootState } from '@redux/store';
import { Toast } from '@utility/functions/toast';
import { useCallback, useEffect, useState } from 'react';
import {
  FilterDataItem,
  MyWorkoutLibraryProps
} from './MyWorkoutLibrary';

const useMyWorkoutLibrary = () => {
  const navigation = useAuthNavigation();
  const {params} = useAuthRoute('MyWorkoutLibrary');
  const isFocus = useIsFocused();
  const {token} = useAppSelector((state: RootState) => state.UserData);

  const [workoutLibrary, setWorkoutLibrary] = useState<MyWorkoutLibraryProps>({
    workoutList: [],
    filteredWorkoutList: [],
    showSelectedCardDetails: false,
    showDeleteModal: false,
    selectedIndex: undefined,
    isLoading: true,
    selectedExercise: {},
    searchedExercise: '',
  });
  const workoutLibraryText = {
    screenTitle: `My Workout Library`,
    searchBarPlaceholder: `Search Exercises`,
    bannerTitle: 'Back Squat',
    instructionTitle: `Coach Instructions`,
    emptyInstruction: `Select an exercise to view it, or\nclick on the “+” button to\nanother exercise to your library`,
    modalTitle: `Delete Exercise`,
    modalDescription: `Are you sure you want to delete Back\nSquats? You will lose it’s data`,
    cancelLabel: 'Cancel',
    confirmLabel: 'Yes',
  };
  useEffect(() => {
    if (isFocus) {
      onGetExercise();
    }
  }, [isFocus]);
  //** Update state values */
  const updateWorkoutLibraryState = useCallback(
    (key: string, value: string | boolean | number | object) => {
      setWorkoutLibrary(prevState => ({...prevState, [key]: value}));
    },
    [workoutLibrary],
  );

  //** Handle card selection */
  const onSelectWorkout = useCallback(
    (index: number, item: object) => {
      updateWorkoutLibraryState('selectedExercise', item);
      updateWorkoutLibraryState('showSelectedCardDetails', true);
      updateWorkoutLibraryState('selectedIndex', index);
      // getExerciseVideo(item?.videoId)
    },
    [workoutLibrary],
  );

  //** Navigate to Add New Exercise Screen */
  const onNavigationToAddNewExercise = useCallback(() => {
    navigation.navigate('NewExercise');
  }, []);

  //** start my workout library list getting api call */
  const onGetExercise = useCallback(async () => {
    try {
      const {data} = await axiosInstance.get(
        `${constant?.baseURL}${constant?.exercises}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );
      if (data) {
        let filteredExercises = data;
        //** start multi filter data conditions */
        if (
          (params?.filterData?.mainMuscle?.length ?? 0) > 0 ||
          (params?.filterData?.type?.length ?? 0) > 0
        ) {
          const {mainMuscle, type} = params?.filterData ?? {};
          const typeData = type?.map(item => item.title);
          const mainMuscleMap = mainMuscle?.map(item => item?.title);
          filteredExercises = data?.filter((item: FilterDataItem) => {
            return (
              mainMuscleMap?.includes(item?.mainMuscle) ||
              typeData?.includes(item?.type)
            );
          });
        }
        //** end multi filter data conditions */
        updateWorkoutLibraryState('workoutList', filteredExercises);
        updateWorkoutLibraryState('filteredWorkoutList', filteredExercises);
        updateWorkoutLibraryState('isLoading', false);
      }
    } catch (error: any) {
      Toast(error?.response?.data?.message);
      updateWorkoutLibraryState('isLoading', false);
    }
  }, [workoutLibrary]);
  //** End my workout library list getting api call */

  //** start Navigate to Library filter screen */
  const navigateToFilterScreen = useCallback(() => {
    navigation.navigate('Filters', {
      filterScreenType: 'myLibrary',
      filterDataPass: params?.filterData,
    });
  }, [params?.filterData]);

  //** Handle referral item search */
  const onSearchExercise = useCallback(
    (text: string) => {
      updateWorkoutLibraryState('searchedExercise', text);
      const filteredList = workoutLibrary?.filteredWorkoutList?.filter(item => {
        return item?.trainerInstructions
          ?.toLowerCase()
          ?.includes(text?.toLowerCase());
      });
      updateWorkoutLibraryState('workoutList', filteredList);
    },
    [workoutLibrary],
  );

  //** Start Exercise video getting api call */
  const getExerciseVideo = async (videoId?: string) => {
    try {
      const {request} = await axiosInstance.get(
        `${constant?.exerciseVideo}${videoId}`,
        {
          responseType: 'arraybuffer',
          headers: {
            Authorization: `Bearer ${token}`,
            'Custom-Header': 'value',
          },
        },
      );
      if (request?._response) {
      }
    } catch (error) {}
  };
  //** End Exercise video getting api call */

  return {
    workoutLibrary,
    workoutLibraryText,
    updateWorkoutLibraryState,
    onSelectWorkout,
    onNavigationToAddNewExercise,
    navigateToFilterScreen,
    onSearchExercise,
  };
};

export default useMyWorkoutLibrary;
