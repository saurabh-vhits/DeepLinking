import imageIndex from '@imageIndex';

export const myWorkoutLibraryList = [
  {
    id: 1,
    title: 'Reverse-grip incline dumbbell bench press',
    bgImage: imageIndex.myWorkoutCardLibrary,
    selectedBgImage: imageIndex.myWorkoutBackground,
  },
  {
    id: 2,
    title: 'Reverse-grip incline dumbbell bench press',
    bgImage: imageIndex.myWorkoutCardLibrary,
    selectedBgImage: imageIndex.myWorkoutBackground,
  },
  {
    id: 3,
    title: 'Reverse-grip incline dumbbell bench press',
    bgImage: imageIndex.myWorkoutCardLibrary,
    selectedBgImage: imageIndex.myWorkoutBackground,
  },
  {
    id: 4,
    bgImage: imageIndex.myWorkoutCardLibrary,
    title: 'Reverse-grip incline dumbbell bench press',
    selectedBgImage: imageIndex.myWorkoutBackground,
  },
  {
    id: 5,
    title: 'Reverse-grip incline dumbbell bench press',
    bgImage: imageIndex.myWorkoutCardLibrary,
    selectedBgImage: imageIndex.myWorkoutBackground,
  },
  {
    id: 6,
    title: 'Reverse-grip incline dumbbell bench press',
    bgImage: imageIndex.myWorkoutCardLibrary,
    selectedBgImage: imageIndex.myWorkoutBackground,
  },
];
