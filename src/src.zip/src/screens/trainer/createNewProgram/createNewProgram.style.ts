import color from '@theme/color';
import font from '@theme/font';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  lable: {
    marginTop: 10,
    fontFamily: font.workSansRegular,
    fontWeight: '500',
    fontSize: 15,
    color: color.primaryText,
  },
  optionalLable: {
    fontFamily: font.workSansRegular,
    fontWeight: '300',
    fontSize: 15,
    lineHeight: 17.6,
    color: color.primaryText,
  },
  videoViewStyle: {
    width: 208,
    marginTop: 10,
  },
  videoStyle: {
    width: '100%',
    height: 117,
  },
  closeImgVideo: {
    backgroundColor: color.transparentColor,
    position: 'absolute',
    right: 10,
    bottom: 80,
  },
  closeImg: {
    backgroundColor: color.transparentColor,
    position: 'absolute',
    right: 5,
    top: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageStyleThumbnail: {
    width: 84,
    height: 84,
  },
  imageStyleThumbnailRatio: {
    width: 164,
    height: 84,
    marginLeft: 16,
    marginTop: 15,
  },
  headerContainerStyle: {
    paddingTop: 14,
    paddingBottom: 19,
    marginTop: 0,
    backgroundColor: color.primaryBG,
    marginBottom: 0,
  },
  inputContentContainers: {
    backgroundColor: color.primaryBG,
    flex: 1,
  },
  inputContent: {
    backgroundColor: color.primaryBG,
    flex: 1,
  },
  ProgramNameInputStyle: {
    borderWidth: 0,
    backgroundColor: color.secondaryBG,
    height: 36,
  },
  programDescription: {
    borderWidth: 0,
    backgroundColor: color.secondaryBG,
    height: 121,
    alignItems: 'flex-start',
    paddingTop: 10,
    borderRadius: 5,
  },
  dropDownContainerStyle: {
    flex: 1,
    marginLeft: 0,
    marginRight: 0,
  },
  dropDownRowView: {
    flex: 1,
    flexDirection: 'row',
    marginBottom: 10,
  },
  rowHorizantal: {
    marginTop: 15,
  },
  imageText: {
    fontSize: 15,
    fontWeight: '500',
    lineHeight: 18,
    fontFamily: font.openSansRegular,
    color: color.primaryText,
    marginTop: 5,
  },
  bottonView: {
    marginTop: 19,
    marginBottom: 22,
  },
  modalContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: color.transparentColorOne,
  },
  modalInnerContainer: {
    width: 315,
    height: 249,
    backgroundColor: color.secondaryBG,
    borderRadius: 10,
    paddingVertical: 20,
  },
  imageStyle: {
    alignSelf: 'center',
  },
  modalTitleText: {
    marginTop: 13,
    textAlign: 'center',
    fontFamily: font.openSansRegular,
    fontWeight: '600',
    fontSize: 14,
    lineHeight: 19.07,
    color: color.primaryText,
    paddingHorizontal: 71,
  },
  modalDesText: {
    marginTop: 31,
    paddingHorizontal: 46,
    textAlign: 'center',
    fontFamily: font.openSansRegular,
    fontWeight: '400',
    fontSize: 14,
    lineHeight: 19.07,
    color: color.primaryText,
  },
  btnView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    marginHorizontal: 28,
    marginTop: 34,
  },
  btnContainer: {
    width: 114,
    backgroundColor: color.primary,
    height: 39,
    borderRadius: 10,
    marginTop: 0,
    paddingTop: 0,
  },
  btnSolidContainer: {
    width: 114,
    backgroundColor: color.deactivatedBG,
    height: 39,
    borderRadius: 10,
    marginTop: 0,
    paddingTop: 0,
  },
  nameTextStyle: {
    fontSize: 14,
    color: color.secondaryBG,
    lineHeight: 19,
    fontFamily: font.openSansRegular,
    fontWeight: '600',
  },
  namesSolidButtonTextStyle: {
    fontSize: 14,
    color: color.primaryText,
    lineHeight: 19,
    fontFamily: font.openSansRegular,
    fontWeight: '600',
  },
  containerStyle: {
    backgroundColor: color.secondaryBG,
    paddingVertical: 0,
  },
  inputTextStyle: {
    padding: 0,
    fontFamily: font.openSansRegular,
    fontSize: 12,
    fontWeight: '400',
  },
  inputLabelStyle: {
    fontSize: 15,
    fontWeight: '500',
    fontFamily: font.openSansRegular,
    color: color.primaryText,
  },
  dropDownLabelTextStyle: {
    fontFamily: font.openSansRegular,
    fontSize: 15,
    color: color.primaryText,
    fontWeight: '500',
    letterSpacing: 0.8,
  },
  dropDownPlaceholderStyle: {
    color: color.primaryText,
    fontSize: 12,
    fontWeight: '400',
  },
  inputMainStyle: {
    marginBottom: 0,
    marginTop: 15,
  },
  inputNameMainStyle: {
    marginBottom: 0,
    marginTop: 0,
  },
  errorLabel: {
    marginTop: 65,
  },
  dropDownSpaceManage: {
    width: 21,
  },
  headerLabelStyle: {
    fontFamily: font.openSansRegular,
    fontSize: 20,
  },
  thumbnailView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  uploadCardContainer: {
    paddingRight: 0,
    paddingLeft: 0,
  },
  uploadCardContainerImage: {
    height: 84,
    width: 84,
    paddingRight: 0,
    paddingLeft: 0,
    marginTop: 15,
    borderRadius: 5,
  },
  uploadCardTrailerContainer: {
    width: 208,
    height: 117,
  },
  uploadImageStyle: {
    paddingHorizontal: 10,
    height: 84,
    width: 84,
  },
  uploadImageRatioStyle: {
    width: 164,
  },
  languageView: {
    flex: 1,
  },
  languageLable: {
    fontFamily: font.openSansMedium,
    fontSize: 15,
    color: color.primaryText,
  },
  languageCard: {
    marginTop: 8,
    height: 36,
    backgroundColor: color.secondaryBG,
    borderRadius: 5,
    paddingLeft: 10,
    paddingRight: 20,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
  },
  languagePlaceholder: {
    fontSize: 12,
    lineHeight: 16.34,
    fontWeight: '400',
    fontFamily: font.openSansRegular,
    color: color.primaryText,
  },
  valueText: {
    fontFamily: font.openSansSemiBold,
    fontWeight: '600',
    fontSize: 12,
    lineHeight: 16.34,
    flex: 1,
    color: color.primaryText,
  },
});

export default styles;
