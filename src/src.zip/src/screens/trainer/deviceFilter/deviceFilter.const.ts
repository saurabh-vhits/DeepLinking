export const deviceList = [
  {id: 1, title: 'iOS', value: false},
  {id: 2, title: 'Android', value: false},
];
