import {ProgramsCard, WeekCard} from '@card';
import {
  Button,
  ClipCard,
  CollapsibleCard,
  ConfirmationModal,
  Container,
  EmptyContainer,
  InputContainer,
} from '@components';
import imageIndex from '@imageIndex';
import SvgIndex from '@svgIndex';
import color from '@theme/color';
import React, {FC} from 'react';
import {
  FlatList,
  ImageBackground,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import useWorkoutPlan from './useWorkoutPlan';
import styles from './workoutPlan.style';
import {
  WeekData,
  WeekDataSecond,
  expandAllDataSession,
  packagePlanList,
  typeData,
} from './workoutPlanData.const';
import svgIndex from '@svgIndex';

export interface WorkoutPlanStateProps {
  selectedIndex?: number;
  publishConfirmationModal: boolean;
  priceStructureSelected: boolean;
  priceUsd: string;
  programId: string;
  isLoading: boolean;
}
const WorkoutPlan: FC = () => {
  const {
    onNavigateToWorkOutDetails,
    workoutPlan,
    params,
    updateInputWorkoutPlanValue,
    onNavigateToMyPrograms,
    onPublish,
  } = useWorkoutPlan();
  return (
    <View style={styles.containerBg}>
      <Container
        wrapperType="scroll"
        lable={
          params?.typeScreen == 'packages'
            ? 'Yash’s amazing package plan'
            : 'Yash’s amazing workout plan'
        }
        headerShown
        showBackIcon
        statusBarColor={color.primaryBG}
        scrollContainerStyle={styles.container}
        containerViewStyle={styles.container}
        containerStyle={styles.headerContainerStyle}>
        <View style={styles.inputContentContainers}>
          <ImageBackground
            style={styles.bgImageStyle}
            source={imageIndex.programsBG}>
            <View style={styles.manageViewSpaceStyle}>
              <TouchableOpacity
                onPress={onNavigateToWorkOutDetails}
                activeOpacity={0.8}
                style={styles.viewUserStyle}>
                <Text allowFontScaling={false} style={styles.viewUserText}>
                  View as user
                </Text>
                <SvgIndex.eyeBorder />
              </TouchableOpacity>
              {/* <TouchableOpacity
                activeOpacity={0.8}
                style={styles.VideoUserStyle}>
                <Text allowFontScaling={false} style={styles.videoUserText}>
                  Play Trailer
                </Text>
                <SvgIndex.play />
              </TouchableOpacity> */}
            </View>
          </ImageBackground>
          <View>
            <FlatList
              data={typeData}
              contentContainerStyle={styles.contentContainerStyle}
              keyExtractor={index => `${index}`}
              horizontal
              renderItem={({item, index}) => (
                <ClipCard
                  title={item.title}
                  onPress={() => {}}
                  titleStyle={styles.clipText}
                  containerStyle={styles.clipContainer}
                />
              )}
              showsHorizontalScrollIndicator={false}
            />
          </View>
          <View style={styles.titleRowViewStyle}>
            <SvgIndex.target />
            <Text allowFontScaling={false} style={styles.fullTitle}>
              Full body, Abs & Core, Booty, Arms, Resistance
            </Text>
          </View>
          <View style={styles.titleRowViewStyle}>
            <SvgIndex.dumbbel />
            <Text allowFontScaling={false} style={styles.fullTitle}>
              Full body, Abs & Core, Booty, Arms, Resistance
            </Text>
          </View>
          <View style={styles.horizontalStyle}>
            <Text allowFontScaling={false} style={styles.detailsTextStyle}>
              Details
            </Text>
            <Text allowFontScaling={false} style={styles.decriptionTextStyle}>
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in voluptate velit esse
            </Text>
          </View>
          <View style={styles.cardStyleLight}>
            <Text allowFontScaling={false} style={styles.priceStructureText}>
              Price Structure
            </Text>
            <View style={styles.styleRowInputManage}>
              <TouchableOpacity
                onPress={() =>
                  updateInputWorkoutPlanValue('priceStructureSelected', true)
                }>
                {workoutPlan?.priceStructureSelected ? (
                  <SvgIndex.radiofilled />
                ) : (
                  <SvgIndex.radioEmpty />
                )}
              </TouchableOpacity>
              <Text
                allowFontScaling={false}
                style={
                  workoutPlan?.priceStructureSelected
                    ? styles.subscriptionRadioText
                    : styles.priceRadioEmptyText
                }>
                Fixed Price
              </Text>
              <InputContainer
                placeholder="Enter price in USD"
                keyboardType="number-pad"
                value={workoutPlan?.priceUsd}
                onChangeText={res =>
                  updateInputWorkoutPlanValue('priceUsd', res)
                }
                placeholderTextColor={color.primaryText}
                inputContainerStyle={styles.sessionNameInputStyle}
                inputStyle={styles.centnerInputStyle}
                containerStyle={styles.containerStyles}
              />
            </View>
            <View style={styles.styleRowInputManage}>
              <TouchableOpacity
                disabled={true}
                onPress={() =>
                  updateInputWorkoutPlanValue('priceStructureSelected', false)
                }>
                {workoutPlan?.priceStructureSelected ? (
                  <SvgIndex.radioEmpty />
                ) : (
                  <SvgIndex.radiofilled />
                )}
              </TouchableOpacity>
              <Text
                allowFontScaling={false}
                style={
                  workoutPlan?.priceStructureSelected
                    ? styles.priceRadioEmptyText
                    : styles.subscriptionRadioText
                }>
                Subscription
              </Text>
            </View>
            <Text allowFontScaling={false} style={styles.priceDecriptionText}>
              The price you set for your program or package is the amount that
              will be displayed to the potential buyers. However, this price is
              not the final amount that you will receive. The payment processor,
              our platform, and the tax authorities will deduct their respective
              fees and taxes from this price. You can learn more by checking our{' '}
              <Text allowFontScaling={false} style={styles.pricePaymentText}>
                payment policy.
              </Text>
            </Text>
          </View>
          {params?.typeScreen == 'packages' ? (
            <View>
              <Text allowFontScaling={false} style={styles.programsTextStyle}>
                Programs
              </Text>
              <FlatList
                data={packagePlanList}
                contentContainerStyle={styles.contentFlatListStyle}
                keyExtractor={(_, index) => {
                  return `${index}`;
                }}
                ListEmptyComponent={<EmptyContainer />}
                renderItem={({item, index}) => (
                  <ProgramsCard key={index} item={item} index={index} />
                )}
                showsVerticalScrollIndicator={false}
                ListFooterComponent={<View style={styles.footerSpace} />}
              />
            </View>
          ) : (
            <View style={styles.typeStyleCard}>
              <View style={styles.weekStyleBgColor}>
                <View style={styles.weekMainShowSessionView}>
                  <View style={styles.weekRowViewManage}>
                    <Text allowFontScaling={false} style={styles.weekTextStyle}>
                      Week 1
                    </Text>
                  </View>
                  <FlatList
                    data={WeekData}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    keyExtractor={(_, index) => `${index}`}
                    renderItem={({item, index}) => (
                      <WeekCard
                        item={item}
                        key={index}
                        index={index}
                        onPress={() => {}}
                        selectIndex={0}
                        selectBorder={item?.selected}
                      />
                    )}
                  />
                </View>
                <View style={styles.weekMainShowSessionView}>
                  <View style={styles.weekRowViewManage}>
                    <Text allowFontScaling={false} style={styles.weekTextStyle}>
                      Week 2
                    </Text>
                  </View>
                  <FlatList
                    data={WeekDataSecond}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    keyExtractor={(_, index) => `${index}`}
                    renderItem={({item, index}) => (
                      <WeekCard
                        item={item}
                        key={index}
                        index={index}
                        onPress={() => {}}
                        selectBorder={item?.selected}
                      />
                    )}
                  />
                </View>
                <View style={styles.weekMainShowSessionView}>
                  <View style={styles.weekRowViewManage}>
                    <Text allowFontScaling={false} style={styles.weekTextStyle}>
                      Week 3
                    </Text>
                  </View>
                  <FlatList
                    data={WeekDataSecond}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    keyExtractor={(_, index) => `${index}`}
                    renderItem={({item, index}) => (
                      <WeekCard
                        item={item}
                        key={index}
                        index={index}
                        onPress={() => {}}
                        selectBorder={item?.selected}
                      />
                    )}
                  />
                </View>
              </View>
              <FlatList
                data={expandAllDataSession}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.flatListSessionStyle}
                keyExtractor={(_, index) => `${index}`}
                renderItem={({item, index}) => (
                  <CollapsibleCard
                    title={item?.title}
                    containerStyle={styles.CollapsibleCardContainerStyle}
                    contentStyle={styles.CollapsibleContentStyle}
                    collapsedStyle={styles.textCollapsibleStyle}
                    upArrow={svgIndex.openDownArrow}
                    downArrow={svgIndex.viewDownArrow}
                    content={
                      <View style={styles.contentView}>
                        <View style={styles.sessionRowViewStyle}>
                          <Text
                            allowFontScaling={false}
                            style={styles.decTextStyle}>
                            Overhead Kettlebell Swings
                          </Text>
                          <Text
                            allowFontScaling={false}
                            style={styles.repsTextStyle}>
                            Sets: {item?.descriptionsSets} Reps:{' '}
                            {item?.descriptionsReps}
                          </Text>
                        </View>
                        <View style={styles.sessionRowViewStyle}>
                          <Text
                            allowFontScaling={false}
                            style={styles.decTextStyle}>
                            Overhead Kettlebell Swings
                          </Text>
                          <Text
                            allowFontScaling={false}
                            style={styles.repsTextStyle}>
                            Sets: {item?.descriptionsSets} Reps:{' '}
                            {item?.descriptionsReps}
                          </Text>
                        </View>
                        <View style={styles.sessionRowViewStyleBorderZero}>
                          <Text
                            allowFontScaling={false}
                            style={styles.decTextStyle}>
                            Overhead Kettlebell Swings
                          </Text>
                          <Text
                            allowFontScaling={false}
                            style={styles.repsTextStyle}>
                            Sets: {item?.descriptionsSets} Reps:{' '}
                            {item?.descriptionsReps}
                          </Text>
                        </View>
                      </View>
                    }
                  />
                )}
              />
            </View>
          )}
        </View>
      </Container>
      <Button
        onPress={onPublish}
        label="Publish"
        containerStyle={styles.buttonContainerStyles}
        marginHorizontal={68}
        isLoading={workoutPlan?.isLoading}
      />
      <ConfirmationModal
        visible={workoutPlan?.publishConfirmationModal}
        animationType="slide"
        image={imageIndex.sheetCongratulations}
        titleText={`Congratulations!`}
        titleTextStyle={styles.congratulationsTitle}
        desText={
          params?.typeScreen == 'packages'
            ? 'Your package is now published. You can see the package on the program screen.'
            : 'Your program is now published. You can see the program on the program screen.'
        }
        confirmLabel="Done"
        onConfirm={onNavigateToMyPrograms}
        confirmBtnStyle={styles.confirmBtnStyle}
        desTextStyle={styles.congratulationsDescriptionText}
        modalInnerContainerStyle={styles.modalStyle}
        imageStyle={styles.modalImageStyle}
      />
    </View>
  );
};

export default WorkoutPlan;
