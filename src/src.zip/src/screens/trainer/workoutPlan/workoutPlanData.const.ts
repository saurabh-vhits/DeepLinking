import imageIndex from "@imageIndex";

export const typeData = [
  {
    id: 1,
    title: 'Length: 2 weeks',
  },
  {
    id: 2,
    title: 'Level: Beginner',
  },
  {
    id: 3,
    title: 'Type: Gym',
  },
];
export const sessionData = [
  {
    id: 1,
    title: 'Session 1',
  },
  {
    id: 2,
    title: 'Session 2',
  },
];
export const WeekData = [
  {
    id: 1,
    title: 1,
    selected: false,
  },
  {
    id: 2,
    title: 2,
    selected: false,
  },
  {
    id: 3,
    title: 3,
    selected: true,
  },
  {
    id: 4,
    title: 4,
    selected: false,
  },
  {
    id: 5,
    title: 5,
    selected: true,
  },
  {
    id: 6,
    title: 6,
    selected: false,
  },
  {
    id: 7,
    title: 7,
    selected: true,
  },
];
export const WeekDataSecond = [
  {
    id: 1,
    title: 1,
    selected: false,
  },
  {
    id: 2,
    title: 2,
    selected: true,
  },
  {
    id: 3,
    title: 3,
    selected: false,
  },
  {
    id: 4,
    title: 4,
    selected: true,
  },
  {
    id: 5,
    title: 5,
    selected: false,
  },
  {
    id: 6,
    title: 6,
    selected: true,
  },
  {
    id: 7,
    title: 7,
    selected: false,
  },
];
export const expandAllDataSession = [
  {
    id: 1,
    title: 'Session 1',
    descriptions: 'Overhead Kettlebell Swings',
    descriptionsSets: '3',
    descriptionsReps: '12',
  },
  {
    id: 2,
    title: 'Session 2',
    descriptions: 'Overhead Kettlebell Swings',
    descriptionsSets: '3',
    descriptionsReps: '12',
  },
];

export const packagePlanList = [
  {
    id: 1,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 2,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 3,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 4,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
  {
    id: 5,
    image: imageIndex.programs,
    title: 'Cross-fit 30 min body weight only full tone exercise',
    descriptions: 'Full body, Abs & Core, Booty, Arms | Resistance',
  },
];