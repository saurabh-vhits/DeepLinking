import {axiosInstance} from '@api/api';
import constant from '@config/constant';
import {useAuthNavigation, useAuthRoute} from '@hooks/useAppNavigation';
import {useAppSelector} from '@hooks/useRedux';
import {useIsFocused} from '@react-navigation/native';
import {useCallback, useEffect, useState} from 'react';
import {WorkoutPlanStateProps} from './WorkoutPlan';

const useWorkoutPlan = () => {
  const navigation = useAuthNavigation();
  const {params} = useAuthRoute('WorkoutPlan');
  const {token} = useAppSelector(state => state.UserData);
  const isFocused = useIsFocused();
  const [workoutPlan, setWorkoutPlan] = useState<WorkoutPlanStateProps>({
    selectedIndex: undefined,
    publishConfirmationModal: false,
    priceStructureSelected: true,
    priceUsd: '',
    programId: '',
    isLoading: false,
  });

  useEffect(() => {
    if (isFocused) {
      if (params?.programId) {
        updateInputWorkoutPlanValue('programId', params?.programId);
      }
    }
  }, [isFocused]);

  //** Handles the change of state values */
  const updateInputWorkoutPlanValue = useCallback(
    (key: string, value: string | boolean | undefined | number) => {
      setWorkoutPlan(prevState => ({...prevState, [key]: value}));
    },
    [workoutPlan],
  );

  //** Navigate to Work out Details screen */
  const onNavigateToWorkOutDetails = useCallback(() => {
    if (params?.typeScreen == 'packages') {
      navigation.navigate('ProgramDetails');
    } else {
      navigation.navigate('WorkoutDetails');
    }
  }, []);

  //** Expand View show and hide function */
  const onExpandClick = useCallback(
    (index: number) => {
      if (workoutPlan?.selectedIndex == index) {
        updateInputWorkoutPlanValue('selectedIndex', undefined);
      } else {
        updateInputWorkoutPlanValue('selectedIndex', index);
      }
    },
    [workoutPlan],
  );

  //** Navigate to Work My Programs */
  const onNavigateToMyPrograms = useCallback(() => {
    updateInputWorkoutPlanValue('publishConfirmationModal', false);
    navigation.navigate('MyPrograms');
  }, [workoutPlan]);

  //** Publish program */
  const onPublish = async () => {
    updateInputWorkoutPlanValue('isLoading', true);
    try {
      const {data} = await axiosInstance.get(
        `${constant.programsPublish}/${workoutPlan?.programId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );
      updateInputWorkoutPlanValue('isLoading', false);
      updateInputWorkoutPlanValue('publishConfirmationModal', true);
    } catch (error) {
      updateInputWorkoutPlanValue('isLoading', false);
    }
  };

  return {
    onNavigateToWorkOutDetails,
    workoutPlan,
    onExpandClick,
    params,
    updateInputWorkoutPlanValue,
    onNavigateToMyPrograms,
    onPublish,
  };
};

export default useWorkoutPlan;
