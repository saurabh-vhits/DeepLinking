import {MyProgramsCard} from '@card';
import {
  BottomSheet,
  Button,
  Container,
  EmptyContainer,
  Loader,
  ModalComponent,
  SearchBar,
} from '@components';
import imageIndex from '@imageIndex';
import {default as SvgIndex, default as svgIndex} from '@svgIndex';
import color from '@theme/color';
import React, {FC} from 'react';
import {
  FlatList,
  Image,
  RefreshControl,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import RBSheet from 'react-native-raw-bottom-sheet';
import {ProgramsItemProps} from 'src/components/card/myProgramsCard/MyProgramsCard';
import {bottomSheetList} from './myPrograms.const';
import styles from './myPrograms.style';
import useMyPrograms from './useMyPrograms';

export interface MyProgramsStateProps {
  myProgramsList: ProgramsItemProps[];
  filterProgramsList: ProgramsItemProps[];
  listType: 'Programs' | 'Packages';
  searchedProgram: string;
  deleteModal: boolean;
  isLoading: boolean;
  isRefreshing: boolean;
}
export interface ProgramListItemProps {
  date: string;
  level: string;
  numberOfWeeks: number;
  price: number;
  retention: number;
  status: string;
}
export interface MuscleListItemProps {
  id: number;
  title: string;
  checked: boolean;
}
export interface FilterDataPass {
  library?: MuscleListItemProps[];
  type?: MuscleListItemProps[];
  mainMuscle?: MuscleListItemProps[];
  level?: MuscleListItemProps[];
  status?: MuscleListItemProps[];
  price?: number;
  numberWeeks?: number;
  lowWeek?: number;
  highWeek?: number;
  highPrice?: number;
  lowPrice?: number;
}

const MyPrograms: FC = () => {
  const {
    programsState,
    refRBSheet,
    isPrograms,
    params,
    onRefreshMyPrograms,
    managePackagesList,
    onSelectPackages,
    onSearchPrograms,
    openBottomSheet,
    navigateToCreatePackages,
    navigateToCreateProgram,
    navigateToMyProgramsFilter,
    navigateToMyWorkoutLibrary,
  } = useMyPrograms();

  const renderItem = ({
    item,
    index,
  }: {
    item: ProgramsItemProps;
    index: number;
  }) => (
    <MyProgramsCard
      key={index}
      item={item}
      index={index}
      onPress={() => {
        isPrograms ? openBottomSheet() : onSelectPackages(item?.programId);
      }}
      showCheckBox={!isPrograms && item.status == 'Active'}
      isSelected={item?.isChecked}
      showStatus={isPrograms ? isPrograms : item.status !== 'Active'}
      anotherStatusDeActive={!isPrograms && item.status !== 'Active'}
    />
  );

  return (
    <>
      <Container
        wrapperType="simple"
        statusBarColor={color.primaryBG}
        scrollContainerStyle={styles.screenBackgroundContainerStyle}
        containerViewStyle={styles.screenBackgroundContainerStyle}>
        <Text allowFontScaling={false} style={styles.headingText}>
          My Programs
        </Text>
        <SearchBar
          placeholder={`Search programs`}
          placeholderTextColor={color.secondaryBG}
          showFilterIcon={true}
          showFolderIcon={true}
          containerStyle={styles.searchContainerStyle}
          searchIcon={svgIndex.searchWhite}
          onPressFilter={navigateToMyProgramsFilter}
          onPressFolder={navigateToMyWorkoutLibrary}
          value={programsState?.searchedProgram}
          setValue={onSearchPrograms}
          selectionColor={color.secondaryText}
          autoCorrect={true}
        />
        <View style={styles.mainContainer}>
          {programsState?.listType == 'Programs' && (
            <View style={styles.btnRowView}>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.btnOutlineStyle}
                onPress={() => managePackagesList('Packages')}>
                <svgIndex.plusPurple />
                <Text allowFontScaling={false} style={styles.btnOutlineText}>
                  Create new Package
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.btnSolidStyle}
                onPress={navigateToCreateProgram}>
                <svgIndex.plus />
                <Text allowFontScaling={false} style={styles.btnSolidText}>
                  Create new Program
                </Text>
              </TouchableOpacity>
            </View>
          )}
          <View style={styles.listView}>
            {programsState?.isLoading ? (
              <Loader />
            ) : (
              <>
                {!programsState?.myProgramsList?.length &&
                !params?.filterData ? (
                  <View style={styles.sessionMainView}>
                    <SvgIndex.sessionSheet />
                    <Text
                      allowFontScaling={false}
                      style={styles.createNewProgramsText}>
                      You haven't created any programs so far. Click on{' '}
                      <Text
                        onPress={navigateToCreateProgram}
                        style={styles.createNewProgramsSelectText}>
                        Create new program
                      </Text>{' '}
                      button{'\n'} to start adding programs here
                    </Text>
                  </View>
                ) : (
                  <FlatList
                    data={programsState?.myProgramsList}
                    contentContainerStyle={styles.contentContainer}
                    keyExtractor={(_, index) => {
                      return `${index}`;
                    }}
                    renderItem={renderItem}
                    showsVerticalScrollIndicator={false}
                    refreshing={programsState?.isRefreshing}
                    refreshControl={
                      <RefreshControl
                        tintColor={color.primaryText}
                        refreshing={programsState?.isRefreshing}
                        onRefresh={onRefreshMyPrograms}
                      />
                    }
                    ListEmptyComponent={
                      params?.filterData && <EmptyContainer />
                    }
                  />
                )}
              </>
            )}
          </View>
        </View>
        <RBSheet
          ref={refRBSheet}
          customStyles={{
            wrapper: styles.rbsheetStyle,
            container: styles.bottomSheetContainer,
          }}
          customModalProps={{
            animationType: 'slide',
          }}>
          {bottomSheetList?.map((item, index) => (
            <BottomSheet key={index} item={item} index={index} />
          ))}
        </RBSheet>
      </Container>
      {programsState?.listType == 'Packages' && (
        <View style={styles.btnView}>
          <Button
            type="Outline"
            label="Cancel"
            containerStyle={styles.cancelBtnStyle}
            nameTextStyle={styles.cancelBtnText}
            onPress={() => managePackagesList('Programs')}
          />
          <Button
            type="Solid"
            label="Create Package"
            containerStyle={styles.createPackagesBtnStyle}
            nameTextStyle={styles.createPackagesStyle}
            onPress={navigateToCreatePackages}
            leftIcon={svgIndex.plus}
          />
        </View>
      )}
      <ModalComponent
        visible={programsState?.deleteModal}
        animationType="fade"
        containerStyle={styles.modalContainer}
        statusBar>
        <View style={styles.modalInnerContainer}>
          <Image
            source={imageIndex.deleteAccount}
            resizeMode="contain"
            style={styles.imageStyle}
          />
          <Text allowFontScaling={false} style={styles.modalDesText}>
            Are you sure you want to delete{' '}
            <Text allowFontScaling={false} style={styles.modalDestTitleText}>
              “Program Name”?
            </Text>
          </Text>
          <Text allowFontScaling={false} style={styles.modalDescriptionText}>
            Deleting the program will remove the program from the marketplace
            but those who are subscribes can still do it.
          </Text>
          <View style={styles.btnView}>
            <Button
              label="Yes"
              type="Solid"
              containerStyle={styles.btnCancelContainer}
              nameTextStyle={styles.nameTextStyle}
            />
            <Button
              label="Cancel"
              type="Solid"
              containerStyle={styles.btnContainer}
              nameTextStyle={styles.nameTextButtonCancelStyle}
            />
          </View>
        </View>
      </ModalComponent>
    </>
  );
};

export default MyPrograms;
