import SvgIndex from '@svgIndex';

export const bottomSheetList = [
  {id: 1, title: 'Copy link', icon: SvgIndex?.copy},
  {id: 2, title: 'Share', icon: SvgIndex?.reply},
  {id: 3, title: 'Edit', icon: SvgIndex?.edit},
  {id: 4, title: 'Deactivate', icon: SvgIndex?.deactivate},
  {id: 5, title: 'Delete', icon: SvgIndex?.deletePurpal},
];
