import {axiosInstance} from '@api/api';
import constant from '@config/constant';
import {useAuthNavigation, useAuthRoute} from '@hooks/useAppNavigation';
import {useAppDispatch, useAppSelector} from '@hooks/useRedux';
import {useIsFocused} from '@react-navigation/native';
import {RootState} from '@redux/store';
import {updateToken} from '@redux/userReducer/reducer';
import {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import RBSheet from 'react-native-raw-bottom-sheet';
import {MyProgramsStateProps, ProgramListItemProps} from './MyPrograms';
import {Log} from '@utility/log';

const useMyPrograms = () => {
  const isFocused = useIsFocused();
  const navigation = useAuthNavigation();
  const {params} = useAuthRoute('MyPrograms');
  const dispatch = useAppDispatch();
  const refRBSheet = useRef<RBSheet>(null);
  const {token, refreshToken} = useAppSelector(
    (state: RootState) => state.UserData,
  );
  const [programsState, setProgramsState] = useState<MyProgramsStateProps>({
    myProgramsList: [],
    filterProgramsList: [],
    listType: 'Programs',
    searchedProgram: '',
    deleteModal: false,
    isLoading: false,
    isRefreshing: false,
  });

  //** Update my programs state */
  const updateMyProgramsState = useCallback(
    (
      key: keyof MyProgramsStateProps,
      value: string | boolean | Array<object>,
    ) => {
      setProgramsState(prevState => ({...prevState, [key]: value}));
    },
    [],
  );

  const isPrograms = useMemo(
    () => programsState?.listType === 'Programs',
    [programsState?.listType],
  );

  useEffect(() => {
    managePackagesList('Programs');
    if (isFocused) {
      refreshTokenUpdate();
    }
  }, [isFocused]);

  useEffect(() => {
    updateMyProgramsState('isLoading', true);
    getMyProgramList();
  }, [token, updateMyProgramsState]);

  //** Referesh location api */
  const onRefreshMyPrograms = useCallback(() => {
    updateMyProgramsState('isRefreshing', true);
    getMyProgramList();
  }, [programsState, updateMyProgramsState]);

  /** Start api for refresh access token */
  const refreshTokenUpdate = async () => {
    try {
      const {headers} = await axiosInstance.get(constant.refreshToken, {
        headers: {
          Authorization: `Bearer ${refreshToken}`,
        },
      });
      const updatedToken = headers?.['set-cookie']
        ?.find(cookie => cookie?.includes('accessToken'))
        ?.split(';')[0]
        .split('=')[1];
      dispatch(updateToken(updatedToken));
    } catch (error) {
      Log('Error refreshing token:', error);
    }
  };
  /** End api for refresh access token */

  /** Start api call for getting program list */
  const getMyProgramList = async () => {
    try {
      const {data} = await axiosInstance.get(constant.programList, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (data) {
        let newProgramsList = data?.map((item: MyProgramsStateProps) => ({
          ...item,
          isChecked: false,
        }));
        if (params?.filterData) {
          const {level, numberWeeks, price, status} = params?.filterData;
          const levelData = level?.map(item => item.title);
          const statusData = status?.map(item => item.title);
          newProgramsList = data?.filter((item: ProgramListItemProps) => {
            return (
              (levelData?.includes(item?.level) ||
                statusData?.includes(item?.status)) &&
              (numberWeeks ? item?.numberOfWeeks === numberWeeks : true) &&
              (price ? item?.price === price : true)
            );
          });
        }
        updateMyProgramsState('myProgramsList', newProgramsList);
        updateMyProgramsState('filterProgramsList', newProgramsList);
        updateMyProgramsState('isLoading', false);
        updateMyProgramsState('isRefreshing', false);
      }
    } catch (error) {
      Log('Error myProgramsList :', error);
      updateMyProgramsState('isLoading', false);
      updateMyProgramsState('isRefreshing', false);
    }
  };
  /** End api call for getting program list */

  //** Start sort packages data based on status  */
  const managePackagesList = useCallback(
    (type: string) => {
      if (type === 'Programs') {
        updateMyProgramsState('myProgramsList', programsState?.myProgramsList);
        updateMyProgramsState('listType', 'Programs');
      } else {
        updateMyProgramsState('listType', 'Packages');
        const sorted = [...(programsState?.myProgramsList || [])]?.sort(
          (a, b) =>
            a?.status === 'Active' && b?.status !== 'Active'
              ? -1
              : a?.status !== 'Active' && b?.status === 'Active'
              ? 1
              : 0,
        );
        updateMyProgramsState('myProgramsList', sorted);
      }
    },
    [programsState, updateMyProgramsState],
  );
  //** End sort packages data based on status  */

  //** Handle package selection */
  const onSelectPackages = useCallback(
    (id?: string) => {
      const updatedData = programsState?.myProgramsList?.map(item => {
        if (item?.programId === id && item?.status === 'Active') {
          return {...item, isChecked: !item?.isChecked};
        }
        return item;
      });
      updateMyProgramsState('myProgramsList', updatedData);
    },
    [programsState, updateMyProgramsState],
  );

  /** Handle search programs item */
  const onSearchPrograms = (text: string) => {
    let filterData = programsState?.filterProgramsList?.filter(item => {
      const itemData = `${item?.name}`;
      const textData = text?.toLowerCase();
      return itemData?.toLowerCase()?.includes(textData);
    });
    updateMyProgramsState('searchedProgram', text);
    updateMyProgramsState('myProgramsList', filterData);
  };

  //** Navigate to create packages screen */
  const navigateToCreatePackages = useCallback(() => {
    navigation.navigate('CreateNewPackages');
  }, [navigation]);

  // //** Navigate to create program screen */
  // Direct navigation without useCallback
  const navigateToCreateProgram = () => {
    navigation.navigate('CreateNewProgram');
  };

  // const navigateToCreateProgram = useCallback(() => {
  //   navigation.navigate('CreateNewProgram');
  // }, [navigation]);

  //** Open my programs operations bottom sheet */
  const openBottomSheet = useCallback(() => {
    refRBSheet.current?.open();
  }, [refRBSheet]);

  //** Navigate to filter screen */
  const navigateToMyProgramsFilter = useCallback(() => {
    navigation.navigate('Filters', {
      filterScreenType: 'myPrograms',
      filterDataPass: params?.filterData,
    });
  }, [params?.filterData, navigation]);

  //** Navigate to my workout library */
  const navigateToMyWorkoutLibrary = useCallback(() => {
    navigation.navigate('MyWorkoutLibrary');
  }, [navigation]);

  return {
    programsState,
    refRBSheet,
    params,
    isPrograms,
    onRefreshMyPrograms,
    managePackagesList,
    onSelectPackages,
    openBottomSheet,
    onSearchPrograms,
    navigateToCreatePackages,
    navigateToCreateProgram,
    navigateToMyProgramsFilter,
    navigateToMyWorkoutLibrary,
  };
};

export default useMyPrograms;
