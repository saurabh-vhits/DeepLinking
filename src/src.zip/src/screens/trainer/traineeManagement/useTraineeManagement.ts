import { useAuthNavigation } from '@hooks/useAppNavigation';
import { useCallback, useState } from 'react';
import { TraineeManagementProps } from './TraineeManagement';
import {
  chartInformationList,
  graphFilters,
  subscriptions,
  traineeManagementList,
} from './traineeManagement.const';

const useTraineeManagement = () => {
  const navigation = useAuthNavigation();
  const [traineeManagement, setTraineeManagement] =
    useState<TraineeManagementProps>({
      traineeList: traineeManagementList,
      chartInformation: chartInformationList,
      graphFilterOptions: graphFilters,
      subscriptions: subscriptions,
      selectedValue: 'Last Week',
      isExpandedAll: false,
    });

  //** Handle state change values */
  const updateTraineeManagementState = useCallback(
    (key: string, value: string | boolean) => {
      setTraineeManagement(prevState => ({...prevState, [key]: value}));
    },
    [traineeManagement],
  );

  //** Handle expand all card */
  const handleExpandAll = useCallback(() => {
    updateTraineeManagementState(
      'isExpandedAll',
      !traineeManagement?.isExpandedAll,
    );
  }, [traineeManagement]);

  //** Handle filter onpress */
  const navigateToFilterScreen = useCallback(() => {
    navigation.navigate('AnalyticsFilters');
  }, []);

  return {
    traineeManagement,
    updateTraineeManagementState,
    handleExpandAll,
    navigateToFilterScreen,
  };
};
export default useTraineeManagement;
