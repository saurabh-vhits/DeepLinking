import {useAuthNavigation} from '@hooks/useAppNavigation';
import {useCallback, useMemo, useState} from 'react';
import {emailChangeProps} from './ChangeEmail';

const useChangeEmail = () => {
  const navigation = useAuthNavigation();
  const [emailChange, setEmailChange] = useState<emailChangeProps>({
    currentEmail: 'Orrdulev123@gmail.com',
    email: '',
    verificationCode: '',
    changeStep: 0,
    confirmationModal: false,
  });
  const [emailChangeError, setEmailChangeError] = useState({
    emailError: undefined,
    verificationCodeError: undefined,
  });

  //** Handle state change */
  const updateEmailChange = useCallback(
    (key: string, value: string | boolean | number) => {
      setEmailChange(prevState => ({...prevState, [key]: value}));
    },
    [emailChange],
  );

  //** Handle next button isDisabled & isActive */
  const isNext = useMemo(() => !emailChange?.verificationCode, [emailChange]);

  //** Navigate to change email screen */
  const onPressNext = useCallback(() => {
    setEmailChange(prevState => ({
      ...prevState,
      changeStep: prevState.changeStep + 1,
    }));
    // navigation.navigate('ChangeEmail');
  }, []);

  //** Confirmations modal */
  const handleModal = useCallback(() => {
    updateEmailChange('confirmationModal', !emailChange?.confirmationModal);
  }, [emailChange]);

  return {
    emailChange,
    updateEmailChange,
    isNext,
    onPressNext,
    handleModal,
  };
};

export default useChangeEmail;
