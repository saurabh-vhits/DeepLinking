import imageIndex from '@imageIndex';

const crossfitList = [
  {id: 1, title: 'crossfit', selected: false},
  {id: 2, title: 'crossfit', selected: true},
  {id: 3, title: 'crossfit', selected: false},
  {id: 4, title: 'crossfit', selected: true},
  {id: 5, title: 'crossfit', selected: false},
  {id: 6, title: 'crossfit', selected: false},
];

const workoutPlans = [
  {
    id: 1,
    tag: 'crossfit',
    rating: 4.7,
    subscriber: '16k',
    title: 'Bodyweight only',
    duration: '12 weeks',
    level: 'intermediate',
    name: 'Alex Margot',
    backgroundImage: imageIndex.frame,
    price: '12.99',
  },
  {
    id: 2,
    tag: 'yoga',
    rating: 4.5,
    subscriber: '12k',
    title: 'Mind and Body',
    duration: '8 weeks',
    level: 'beginner',
    name: 'Jessica Smith',
    backgroundImage: imageIndex.frame,
    price: '9.99',
  },
  {
    id: 3,
    tag: 'running',
    rating: 4.8,
    subscriber: '20k',
    title: 'Couch to 5k',
    duration: '10 weeks',
    level: 'beginner',
    name: 'Mike Johnson',
    backgroundImage: imageIndex.frame,
    price: '7.99',
  },
  {
    id: 4,
    tag: 'weightlifting',
    rating: 4.6,
    subscriber: '18k',
    title: 'Powerlifting',
    duration: '16 weeks',
    level: 'intermediate',
    name: 'Sarah Lee',
    backgroundImage: imageIndex.frame,
    price: '14.99',
  },
  {
    id: 5,
    tag: 'cycling',
    rating: 4.9,
    subscriber: '14k',
    title: 'Road Cycling',
    duration: '14 weeks',
    level: 'advanced',
    name: 'David Kim',
    backgroundImage: imageIndex.frame,
    price: '19.99',
  },
];

const reviewsList = [
  {
    id: 1,
    profileImage: imageIndex.profileImage,
    time: '3d',
    review: 'Cool program! quite intense but definitely you can see results!',
    rating: 4.9,
  },
  {
    id: 2,
    profileImage: imageIndex.profileImage,
    time: '1w',
    review: 'Cool program! quite intense but definitely you can see results!',
    rating: 4.7,
  },
  {
    id: 3,
    profileImage: imageIndex.profileImage,
    time: '2w',
    review: 'Cool program! quite intense but definitely you can see results!',
    rating: 4.8,
  },
  {
    id: 4,
    profileImage: imageIndex.profileImage,
    time: '1m',
    review: 'Cool program! quite intense but definitely you can see results!',
    rating: 4.6,
  },
  {
    id: 5,
    profileImage: imageIndex.profileImage,
    time: '3m',
    review: 'Cool program! quite intense but definitely you can see results!',
    rating: 4.9,
  },
];

export {crossfitList, workoutPlans, reviewsList};
