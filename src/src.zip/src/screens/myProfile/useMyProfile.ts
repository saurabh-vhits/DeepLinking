import {useAuthNavigation} from '@hooks/useAppNavigation';
import {useCallback, useState} from 'react';
import {MyProfileProps} from './MyProfile';
import {crossfitList, reviewsList, workoutPlans} from './myProfileData.const';

type Key = 'crossfitList' | 'workoutPlans' | 'reviewsList';

const useMyProfile = () => {
  const navigation = useAuthNavigation();
  const [profileInfo, setProfileInfo] = useState<MyProfileProps>({
    crossfitList,
    workoutPlans,
    reviewsList,
  });

  // **Handle state update**
  const updateProfileState = useCallback(
    <T extends unknown[]>(key: Key, value: T) => {
      setProfileInfo(prevState => ({...prevState, [key]: value}));
    },
    [profileInfo],
  );

  // **Navigate to edit profile screen**
  const navigateToEditProfile = useCallback(() => {
    navigation.navigate('EditProfile');
  }, [navigation]);

  return {
    profileInfo,
    navigateToEditProfile,
    updateProfileState,
  };
};

export default useMyProfile;