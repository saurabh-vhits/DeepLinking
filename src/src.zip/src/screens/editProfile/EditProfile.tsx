import {Button, ClipCard, Container, InputContainer} from '@components';
import imageIndex from '@imageIndex';
import svgIndex from '@svgIndex';
import React, {FC} from 'react';
import {
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import styles from './editProfile.style';
import {expertiseAddData} from './editProfile.const';
import useEditProfile from './useEditProfile';

export interface EditProfileProps {
  firstName?: string;
  lastName?: string;
  education?: string;
  location?: string;
  experience?: string;
  about?: string;
  instagram?: string;
  tikTok?: string;
  youTube?: string;
  profile?: string;
  backgroundProfile?: string;
  isLoading?: boolean;
}
export interface EditProfileErrorProps {
  firstNameError?: string;
  lastNameError?: string;
  educationError?: string;
  locationError?: string;
  experienceError?: string;
  aboutError?: string;
  instagramError?: string;
  tikTokError?: string;
  youTubeError?: string;
}

const EditProfile: FC = () => {
  const {
    editProfile,
    editProfileError,
    updateEditProfileState,
    onOpenImagePicker,
    navigationToLocationScreen,
  } = useEditProfile();
  return (
    <KeyboardAvoidingView
      style={styles.keyView}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Container
        wrapperType="scroll"
        headerShown
        lable="Edit Profile"
        showBackIcon
        containerStyle={styles.headerContainerStyle}
        containerViewStyle={styles.containerViewStyle}
        lableStyle={styles.lableStyle}>
        <Image
          style={styles.backgroundImageStyle}
          source={
            editProfile?.backgroundProfile
              ? {uri: editProfile?.backgroundProfile}
              : imageIndex.profileImage
          }
          resizeMode="cover"
        />
        <View style={styles.userViewImage}>
          <TouchableOpacity
            onPress={() => onOpenImagePicker('profile')}
            style={styles.gallaryImage}>
            <svgIndex.gallary />
          </TouchableOpacity>
          <Image
            style={styles.userImage}
            source={
              editProfile?.profile
                ? {uri: editProfile?.profile}
                : imageIndex.userProfile
            }
            resizeMode="contain"
          />
        </View>
        <TouchableOpacity
          onPress={() => onOpenImagePicker('backgroundProfile')}
          style={styles.selectGallerystyle}>
          <svgIndex.gallary />
        </TouchableOpacity>
        <View style={styles.formView}>
          <InputContainer
            label="First Name"
            placeholder="Enter First Name"
            value={editProfile?.firstName}
            onChangeText={res =>
              updateEditProfileState('firstName', res?.trim())
            }
            keyboardType="default"
            error={editProfileError?.firstNameError}
            containerStyle={styles.containerStyles}
            inputContainerStyle={styles.inputContainerStyle}
            maxLength={20}
          />
          <InputContainer
            label="Last Name"
            placeholder="Enter Last Name"
            value={editProfile?.lastName}
            onChangeText={res =>
              updateEditProfileState('lastName', res?.trim())
            }
            keyboardType="default"
            error={editProfileError?.lastNameError}
            containerStyle={styles.containerStyles}
            inputContainerStyle={styles.inputContainerStyle}
            maxLength={20}
          />
          <InputContainer
            label="Education & Qualification"
            placeholder="Enter Education & Qualification"
            value={editProfile?.education}
            onChangeText={res =>
              updateEditProfileState('education', res?.trim())
            }
            keyboardType="default"
            error={editProfileError?.educationError}
            containerStyle={styles.containerStyles}
            inputContainerStyle={styles.inputContainerStyle}
            editable={false}
            maxLength={40}
          />
          <InputContainer
            label="Location"
            placeholder="Select Location"
            value={editProfile?.location}
            onChangeText={res => updateEditProfileState('location', res)}
            rightElementType="dropdown"
            onPressDropdown={navigationToLocationScreen}
            error={editProfileError?.locationError}
            containerStyle={styles.containerStyles}
            inputContainerStyle={styles.inputContainerStyle}
            editable={false}
          />
          <InputContainer
            label="Year of Experience"
            placeholder="Enter YOE"
            rightElementType="dropdown"
            value={editProfile?.experience}
            onChangeText={res => updateEditProfileState('experience', res)}
            keyboardType="default"
            error={editProfileError?.experienceError}
            containerStyle={styles.containerStyles}
            inputContainerStyle={styles.inputContainerStyle}
            editable={false}
            maxLength={30}
          />
          <InputContainer
            label="About"
            placeholder="Tell more about you..."
            value={editProfile?.about}
            onChangeText={res => updateEditProfileState('about', res)}
            keyboardType="default"
            error={editProfileError?.aboutError}
            containerStyle={styles.containerStyles}
            inputContainerStyle={styles.inputAboutContainerStyle}
            multiline
            maxLength={500}
          />
          <Text allowFontScaling={false} style={styles.socialHeadingText}>
            Social
          </Text>
          <InputContainer
            label="Instagram"
            labelIcon={svgIndex.instagram}
            value={editProfile?.instagram}
            onChangeText={res => updateEditProfileState('instagram', res)}
            placeholder="@  What is your Instagram Handle?"
            keyboardType="email-address"
            containerStyle={styles.containerStylesSocial}
            inputContainerStyle={styles.inputContainerStyle}
          />
          <InputContainer
            label="Tiktok"
            placeholder="@  What is your Tiktok Handle?"
            value={editProfile?.tikTok}
            onChangeText={res => updateEditProfileState('tikTok', res)}
            keyboardType="email-address"
            labelIcon={svgIndex.tiktok}
            containerStyle={styles.containerStylesSocial}
            inputContainerStyle={styles.inputContainerStyle}
          />
          <InputContainer
            label="YouTube"
            placeholder="@  What is your youtube Handle?"
            value={editProfile?.youTube}
            onChangeText={res => updateEditProfileState('youTube', res)}
            keyboardType="email-address"
            labelIcon={svgIndex.ytLable}
            containerStyle={styles.containerStylesSocial}
            inputContainerStyle={styles.inputContainerStyle}
          />
          <TouchableOpacity activeOpacity={0.8} style={styles.expertiseView}>
            <Text allowFontScaling={false} style={styles.textStyle}>
              Add Expertise +
            </Text>
          </TouchableOpacity>
          <FlatList
            data={expertiseAddData}
            contentContainerStyle={styles.contentContainerStyle}
            keyExtractor={(_, index) => `${index}`}
            numColumns={4}
            renderItem={({item, index}) => (
              <ClipCard
                title={item.title}
                onPress={() => {}}
                titleStyle={
                  index === 1 || index === 3
                    ? styles.borderClipColorText
                    : styles.borderClipText
                }
                containerStyle={
                  index === 1 || index === 3
                    ? styles.borderClipColorStyle
                    : styles.borderClipStyle
                }
              />
            )}
            showsHorizontalScrollIndicator={false}
          />
        </View>
      </Container>
      <View style={styles.btnView}>
        <Button
          type="Solid"
          label="Save changes"
          containerStyle={styles.createPackagesBtnStyle}
          nameTextStyle={styles.createPackagesStyle}
        />
      </View>
    </KeyboardAvoidingView>
  );
};

export default EditProfile;
