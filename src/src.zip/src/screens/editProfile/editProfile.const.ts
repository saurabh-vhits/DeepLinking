export const expertiseAddData = [
  {
    id: 1,
    title: 'Crossfit',
  },
  {
    id: 2,
    title: 'Crossfit',
  },
  {
    id: 3,
    title: 'Crossfit',
  },
  {
    id: 4,
    title: 'Crossfit',
  },
  {
    id: 5,
    title: 'Crossfit',
  },
  {
    id: 6,
    title: 'Crossfit',
  },
];
