import { useAuthNavigation, useAuthRoute } from '@hooks/useAppNavigation';
import { useAppSelector } from '@hooks/useRedux';
import { RootState } from '@redux/store';
import { useCallback, useEffect, useState } from 'react';
import ImagePicker from 'react-native-image-crop-picker';
import { EditProfileErrorProps, EditProfileProps } from './EditProfile';

const useEditProfile = () => {
  const navigation = useAuthNavigation();
  const route = useAuthRoute('EditProfile');
  const {userData} = useAppSelector((state: RootState) => state.UserData);
  const [editProfile, setEditProfile] = useState<EditProfileProps>({
    firstName: 'Yash Kaushal',
    lastName: 'Yash Kaushal',
    education: 'Fitness Trainer',
    location: '',
    experience: '5 years',
    about: '',
    instagram: '',
    tikTok: '',
    youTube: '',
    isLoading: false,
    profile: '',
    backgroundProfile: '',
  });
  const [editProfileError, setEditProfileError] =
    useState<EditProfileErrorProps>({
      firstNameError: undefined,
      lastNameError: undefined,
      educationError: undefined,
      locationError: undefined,
      experienceError: undefined,
      aboutError: undefined,
      instagramError: undefined,
      tikTokError: undefined,
      youTubeError: undefined,
    });

  useEffect(() => {
    setEditProfile(prevState => ({
      ...prevState,
      location: route?.params?.selectLocation,
    }));
  }, [route]);

  //** Update edit profile state */
  const updateEditProfileState = useCallback(
    (key: string, value: string) => {
      setEditProfile(prevState => ({...prevState, [key]: value}));
    },
    [editProfile],
  );

  //** Navigate to Location screen */
  const navigationToLocationScreen = useCallback(() => {
    navigation.navigate('Location', {
      flag: 'EditProfile',
      selectedValue: editProfile?.location,
    });
  }, [editProfile]);

  //** Change user profile image  */
  const onOpenImagePicker = (type: string) => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      mediaType: 'photo',
      cropping: true,
    }).then(image => {
      if (type == 'profile') {
        setEditProfile(prevState => ({
          ...prevState,
          profile: image?.path,
        }));
      } else {
        setEditProfile(prevState => ({
          ...prevState,
          backgroundProfile: image?.path,
        }));
      }
    });
  };

  return {
    editProfile,
    editProfileError,
    updateEditProfileState,
    onOpenImagePicker,
    navigationToLocationScreen,
  };
};

export default useEditProfile;
