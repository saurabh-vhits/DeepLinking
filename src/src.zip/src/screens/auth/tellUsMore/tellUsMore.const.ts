const dropDownLocationData = [
  {
    id: 1,
    title: 'India',
  },
  {
    id: 2,
    title: 'Germany',
  },
  {
    id: 3,
    title: 'Australia',
  },
  {
    id: 4,
    title: 'Austra',
  },
  {
    id: 5,
    title: 'Germany',
  },
  {
    id: 6,
    title: 'Australia',
  },
  {
    id: 7,
    title: 'India',
  },
  {
    id: 8,
    title: 'Germany',
  },
  {
    id: 9,
    title: 'India',
  },
  {
    id: 10,
    title: 'Germany',
  },
  {
    id: 11,
    title: 'India',
  },
  {
    id: 12,
    title: 'Germany',
  },
  {
    id: 13,
    title: 'India',
  },
  {
    id: 14,
    title: 'Germany',
  },
];

export default dropDownLocationData;
