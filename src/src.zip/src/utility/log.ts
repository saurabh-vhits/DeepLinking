export const Log = (label: string, value?: any) => {
  // console.log(label, value);
};
