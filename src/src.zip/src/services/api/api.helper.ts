//user mock type MockAdapter
const mockEndpointsProductions = (mock: any): void => {};

export {mockEndpointsProductions};
