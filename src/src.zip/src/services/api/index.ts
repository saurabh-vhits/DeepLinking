import {axiosInstance} from './api';
import {mockEndpointsProductions} from './api.helper';

export {axiosInstance as default, mockEndpointsProductions};
