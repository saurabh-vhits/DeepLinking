import constant from './constant';
import params from './params';

export default {
  constant,
  params,
};
